package com.xlentdevs.xlentlearn.notifications

data class PushNotification(
    val data: NotificationData,
    val to: String,

)
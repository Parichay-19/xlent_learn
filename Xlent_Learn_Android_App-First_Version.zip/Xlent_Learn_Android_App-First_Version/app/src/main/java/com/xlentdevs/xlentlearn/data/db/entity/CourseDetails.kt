package com.xlentdevs.xlentlearn.data.db.entity

data class CourseDetails(
    var id: String = "",
    var name: String = "",
    var thumbnail: String = "",
    var skills: String = "",
    var category: String = ""
)
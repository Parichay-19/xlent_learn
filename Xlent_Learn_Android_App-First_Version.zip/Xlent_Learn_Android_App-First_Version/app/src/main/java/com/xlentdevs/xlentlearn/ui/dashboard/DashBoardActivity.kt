package com.xlentdevs.xlentlearn.ui.dashboard

import android.os.Bundle
import android.view.View
import android.widget.ProgressBar
import androidx.appcompat.app.AppCompatActivity
import androidx.databinding.DataBindingUtil
import androidx.fragment.app.Fragment
import androidx.navigation.NavController
import androidx.navigation.NavOptions
import androidx.navigation.Navigation
import com.xlentdevs.xlentlearn.R
import com.xlentdevs.xlentlearn.databinding.ActivityDashBoardBinding
import com.xlentdevs.xlentlearn.ui.dashboard.course.CourseFragment
import com.xlentdevs.xlentlearn.ui.dashboard.profile.ProfileFragment
import com.xlentdevs.xlentlearn.ui.dashboard.project.ProjectFragment


class DashBoardActivity : AppCompatActivity() {

    lateinit var mainProgressBar: ProgressBar
    lateinit var viewDataBinding: ActivityDashBoardBinding

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        viewDataBinding = DataBindingUtil.setContentView(this, R.layout.activity_dash_board)

        mainProgressBar = findViewById(R.id.main_progressBar)
        setUpNavigation()
    }

    fun showGlobalProgressBar(show: Boolean) {
        if (show) mainProgressBar.visibility = View.VISIBLE
        else mainProgressBar.visibility = View.GONE
    }

    private fun setUpNavigation() {
        val navController: NavController =
            Navigation.findNavController(this, R.id.nav_host_container)

        val navOptions: NavOptions = NavOptions.Builder()
            .setLaunchSingleTop(true)
            .setEnterAnim(R.anim.slide_in_left)
            .setExitAnim(R.anim.slide_out_right)
            .setPopEnterAnim(R.anim.slide_in_left)
            .setPopExitAnim(R.anim.slide_out_right)
            .setPopUpTo(navController.graph.startDestinationId, false)
            .build()

        viewDataBinding.bottomNav.setOnItemSelectedListener { item ->
            var handled = false
            if (navController.graph.findNode(item.itemId) != null) {
                navController.navigate(item.itemId, null, navOptions)
                handled = true
            }
            handled
        }

        viewDataBinding.bottomNav.setOnItemReselectedListener { item ->
            return@setOnItemReselectedListener
        }
    }

    override fun onBackPressed() {
        val navController: NavController =
            Navigation.findNavController(this, R.id.nav_host_container)

        val current = navController.currentDestination!!.id

        if (current == R.id.courseFragment) {
            viewDataBinding.bottomNav.getMenu().getItem(0).setChecked(true)
        } else if (current == R.id.projectFragment) {
            viewDataBinding.bottomNav.getMenu().getItem(0).setChecked(true)
        } else if (current == R.id.profileFragment) {
            viewDataBinding.bottomNav.getMenu().getItem(0).setChecked(true)
        }

        super.onBackPressed()
    }
}
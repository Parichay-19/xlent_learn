package com.xlentdevs.xlentlearn.ui.dashboard.videos

import android.app.Application
import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider

class VideosViewModelFactory(
    private val application: Application,
    private val playlistId: String
): ViewModelProvider.Factory {

    override fun <T : ViewModel> create(modelClass: Class<T>): T {
        if (modelClass.isAssignableFrom(VideosViewModel::class.java)){
            return VideosViewModel(application, playlistId) as T
        }
        throw IllegalArgumentException("Unknown ViewModel !")
    }
}
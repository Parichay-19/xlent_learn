package com.xlentdevs.xlentlearn.data.db.repository

import android.net.Uri
import com.xlentdevs.xlentlearn.data.db.remote.FirebaseStorageSource
import com.xlentdevs.xlentlearn.data.Result

class StorageRepository {
    private val firebaseStorageService = FirebaseStorageSource()

    fun uploadCourseImage(courseName: String, byteArray: ByteArray, b: (Result<Uri>) -> Unit) {
        b.invoke(Result.Loading)
        firebaseStorageService.uploadCourseImage(courseName, byteArray).addOnSuccessListener {
            b.invoke((Result.Success(it)))
        }.addOnFailureListener {
            b.invoke(Result.Error(it.message))
        }
    }

    fun uploadProjectImage(projectName: String, byteArray: ByteArray, b: (Result<Uri>) -> Unit) {
        b.invoke(Result.Loading)
        firebaseStorageService.uploadProjectImage(projectName, byteArray).addOnSuccessListener {
            b.invoke((Result.Success(it)))
        }.addOnFailureListener {
            b.invoke(Result.Error(it.message))
        }
    }

}
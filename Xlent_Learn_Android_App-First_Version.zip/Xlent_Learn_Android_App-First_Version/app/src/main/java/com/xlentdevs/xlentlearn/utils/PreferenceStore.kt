package com.xlentdevs.xlentlearn.utils

import android.content.Context
import androidx.datastore.preferences.core.booleanPreferencesKey
import androidx.datastore.preferences.core.edit
import androidx.datastore.preferences.core.emptyPreferences
import androidx.datastore.preferences.core.stringPreferencesKey
import androidx.datastore.preferences.preferencesDataStore
import com.xlentdevs.xlentlearn.data.db.entity.User
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.catch
import kotlinx.coroutines.flow.map
import java.io.IOException

class PreferenceStore(val context: Context) {

    private val applicationContext = context.applicationContext

    companion object {
        private val Context.dataStore by preferencesDataStore(name = "USERDATA")
        private val USERID = stringPreferencesKey("userId")
        private val NAME = stringPreferencesKey("name")
        private val EMAIL = stringPreferencesKey("email")
        private val PROFILE = stringPreferencesKey("profile")
        private val ADMIN = booleanPreferencesKey("admin")

        private val Context.checkFirstTime by preferencesDataStore("FIRSTUSER")
        private val CHECK = booleanPreferencesKey("firstUser")
    }

    //Saving the user uid
    suspend fun saveAuthToken(id: String, name: String, email: String, profile: String, admin: Boolean) {
        applicationContext.dataStore.edit { preference ->
            preference[USERID] = id
            preference[NAME] = name
            preference[EMAIL] = email
            preference[PROFILE] = profile
            preference[ADMIN] = admin
        }
    }

    suspend fun saveFirstTimeUser(check: Boolean){
        applicationContext.checkFirstTime.edit { prefs->
            prefs[CHECK] = check
        }
    }

    //retreiving the user uid
    val authToken: Flow<User?> =
        applicationContext.dataStore.data
            .catch { exception ->
                if (exception is IOException) {
                    emit(emptyPreferences())
                } else {
                    throw exception
                }
            }.map { preference ->
                val id = preference[USERID] ?: "NA"
                val name = preference[NAME] ?: "NA"
                val email = preference[EMAIL] ?: "NA"
                val profile = preference[PROFILE] ?: "NA"
                val admin = preference[ADMIN] ?: false
                User(id, name, email, profile, admin)
            }

    val checkValue: Flow<Boolean?> =
        applicationContext.checkFirstTime.data
            .catch { exception->
                if (exception is IOException){
                    emit(emptyPreferences())
                } else{
                    throw exception
                }
            }.map { preference->
                val check = preference[CHECK] ?: true
                check
            }
}
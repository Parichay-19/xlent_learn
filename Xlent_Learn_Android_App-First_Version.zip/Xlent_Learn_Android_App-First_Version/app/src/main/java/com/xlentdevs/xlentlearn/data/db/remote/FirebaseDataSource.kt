package com.xlentdevs.xlentlearn.data.db.remote

import androidx.lifecycle.MutableLiveData
import com.google.firebase.database.*
import com.xlentdevs.xlentlearn.data.Result
import com.xlentdevs.xlentlearn.data.db.entity.*
import com.xlentdevs.xlentlearn.utils.wrapSnapshotToArrayList
import com.xlentdevs.xlentlearn.utils.wrapSnapshotToClass

class FirebaseReferenceValueObserver {
    private var valueEventListener: ValueEventListener? = null
    private var dbRef: DatabaseReference? = null
    private var queryRef : Query? = null

    fun start(valueEventListener: ValueEventListener, reference: DatabaseReference) {
        reference.addValueEventListener(valueEventListener)
        this.valueEventListener = valueEventListener
        this.dbRef = reference
    }

    fun query(valueEventListener: ValueEventListener, query: Query){
        query.addValueEventListener(valueEventListener)
        this.valueEventListener = valueEventListener
        this.queryRef = query
    }

    fun clear() {
        valueEventListener?.let { dbRef?.removeEventListener(it) }
        valueEventListener = null
        dbRef = null
    }
}

class FirebaseDataSource {

    companion object {
        val dbInstance =
            FirebaseDatabase.getInstance("https://xlent-learn-default-rtdb.asia-southeast1.firebasedatabase.app/").reference
    }

    private fun refToPath(path: String): DatabaseReference {
        return dbInstance.child(path)
    }

    private fun refToQuery(path: String, text: String): Query{
        return dbInstance.child(path).orderByChild("name").startAt(text).endAt(text + "\uF8FF")
    }

    //--------------------Listeners Starts---------------------
    private fun <T> attachValueListenerToBlock(
        resultClassName: Class<T>,
        b: ((Result<T>) -> Unit)
    ): ValueEventListener {
        return (object : ValueEventListener {
            override fun onCancelled(error: DatabaseError) {
                b.invoke(Result.Error(error.message))
            }

            override fun onDataChange(snapshot: DataSnapshot) {
                if (wrapSnapshotToClass(resultClassName, snapshot) == null) {
                    b.invoke(Result.Error(msg = snapshot.key))
                } else {
                    b.invoke(Result.Success(wrapSnapshotToClass(resultClassName, snapshot)))
                }
            }
        })
    }

    private fun <T> attachValueListenerToBlockWithList(
        resultClassName: Class<T>,
        b: ((Result<MutableList<T>>) -> Unit)
    ): ValueEventListener {
        return (object : ValueEventListener {
            override fun onCancelled(error: DatabaseError) {
                b.invoke(Result.Error(error.message))
            }

            override fun onDataChange(snapshot: DataSnapshot) {
                if (!snapshot.exists()) {
                    b.invoke(Result.Success(mutableListOf()))
                } else {
                    b.invoke(Result.Success(wrapSnapshotToArrayList(resultClassName, snapshot)))
                }
            }
        })
    }
    //-------------------Listeners Ends-------------------------

    //-------------------Updates Starts-------------------------
    fun updateNewUser(path: String, user: User) {
        refToPath("${path}/${user.uid}").setValue(user)
    }

    fun updateNewCourse(path: String, courseDetails: CourseDetails): String {
        val id = refToPath(path).push().key
        courseDetails.id = id!!

        refToPath("${path}/${id}").setValue(courseDetails)
        return id
    }

    fun updateNotificationDetails(path: String, notificationDetails: NotificationDetails): String{
        val id = refToPath(path).push().key
        notificationDetails.id = id!!

        refToPath("${path}/${id}").setValue(notificationDetails)
        return id
    }

    fun updateNewCourseRequest(path: String, requestDetails: RequestDetails): String{
        val id = refToPath(path).push().key
        requestDetails.id = id!!

        refToPath("${path}/${id}").setValue(requestDetails)
        return id
    }

    fun updateNewProject(path: String, projectDetails: ProjectDetails): String {
        val id = refToPath(path).push().key
        projectDetails.id = id!!
        refToPath("${path}/${id}").setValue(projectDetails)
        return id
    }

    fun updateCourseLessons(path: String, courseLesson: String, id: String): Boolean {
        val lesson = Lesson(courseLesson)
        refToPath("${path}/${id}").push().setValue(lesson)
        return true
    }

    fun enrollCourse(path: String, uid: String, courseId: String): Boolean{
        refToPath("users/${uid}/${path}").child(courseId).setValue(courseId)
        refToPath("courseDetails/${courseId}/${path}").child(uid).setValue(courseId)
        return true
    }
    //-------------------Updates Ends---------------------------

    //-------------------Observers Starts-----------------------
    fun <T> attachUserInfoObserver(
        path: String,
        resultClassName: Class<T>,
        userID: String,
        refObs: FirebaseReferenceValueObserver,
        b: ((Result<T>) -> Unit)
    ) {
        val listener = attachValueListenerToBlock(resultClassName, b)
        refObs.start(listener, refToPath("${path}/${userID}"))
    }

    fun <T> attachCourseLessonObserver(
        path: String,
        id: String,
        resultClassName: Class<T>,
        firebaseReferenceValueObserver: FirebaseReferenceValueObserver,
        b: ((Result<MutableList<T>?>) -> Unit)
    ) {
        val listener = attachValueListenerToBlockWithList(resultClassName, b)
        firebaseReferenceValueObserver.start(listener, refToPath("${path}/${id}"))
    }

    fun <T> attachCourseListObserver(
        path: String,
        resultClassName: Class<T>,
        firebaseReferenceValueObserver: FirebaseReferenceValueObserver,
        b: ((Result<MutableList<T>?>) -> Unit)
    ) {
        val listener = attachValueListenerToBlockWithList(resultClassName, b)
        firebaseReferenceValueObserver.start(listener, refToPath(path))
    }

    fun <T> attachProjectListObserver(
        path: String,
        resultClassName: Class<T>,
        firebaseReferenceValueObserver: FirebaseReferenceValueObserver,
        b: ((Result<MutableList<T>?>) -> Unit)
    ) {
        val listener = attachValueListenerToBlockWithList(resultClassName, b)
        firebaseReferenceValueObserver.start(listener, refToPath(path))
    }

    fun <T> attachNotificationListObserver(
        path: String,
        resultClassName: Class<T>,
        firebaseReferenceValueObserver: FirebaseReferenceValueObserver,
        b: ((Result<MutableList<T>?>) -> Unit)
    ) {
        val listener = attachValueListenerToBlockWithList(resultClassName, b)
        firebaseReferenceValueObserver.start(listener, refToPath(path))
    }

    fun <T> attachEnrolledCoursesIdListObserver(
        path:String,
        userID: String,
        resultClass: Class<T>,
        firebaseReferenceValueObserver: FirebaseReferenceValueObserver,
        b: ((Result<MutableList<T>>) -> Unit)
    ){
        val listener = attachValueListenerToBlockWithList(resultClass, b)
        firebaseReferenceValueObserver.start(listener, refToPath("${path}/${userID}/enrolled"))
    }

    fun <T> attachEnrolledCourseObserver(
        path: String,
        resultClassName: Class<T>,
        courseId: String,
        refObs: FirebaseReferenceValueObserver,
        b: ((Result<T>) -> Unit)
    ) {
        val listener = attachValueListenerToBlock(resultClassName, b)
        refObs.start(listener, refToPath("${path}/${courseId}"))
    }
    //-------------------Observers Ends-----------------------

    //-------------------Query Data---------------------------
    fun <T> attachCourseQueryListObserver(
        query: String,
        resultClassName: Class<T>,
        firebaseReferenceValueObserver: FirebaseReferenceValueObserver,
        b: ((Result<MutableList<T>?>) -> Unit)
    ) {
        val listener = attachValueListenerToBlockWithList(resultClassName, b)
        firebaseReferenceValueObserver.query(listener, refToQuery("courseDetails", query))
    }

    fun <T> attachProjectQueryListObserver(
        query: String,
        resultClassName: Class<T>,
        firebaseReferenceValueObserver: FirebaseReferenceValueObserver,
        b: ((Result<MutableList<T>?>) -> Unit)
    ) {
        val listener = attachValueListenerToBlockWithList(resultClassName, b)
        firebaseReferenceValueObserver.query(listener, refToQuery("projectDetails", query))
    }
}
package com.xlentdevs.xlentlearn.ui.dashboard.lessons

import android.app.Application
import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider

class LessonsViewModelFactory(
    private val application: Application,
    private val courseId: String,
    private val type: String,
    private val name: String,
    private val photo: String
): ViewModelProvider.Factory {

    override fun <T : ViewModel> create(modelClass: Class<T>): T {
        if (modelClass.isAssignableFrom(LessonsViewModel::class.java)){
            return LessonsViewModel(application, courseId, type, name, photo) as T
        }
        throw IllegalArgumentException("Unknown ViewModel !")
    }
}
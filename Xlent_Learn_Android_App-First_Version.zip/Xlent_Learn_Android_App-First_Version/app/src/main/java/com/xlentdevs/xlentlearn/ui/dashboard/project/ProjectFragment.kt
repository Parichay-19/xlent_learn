package com.xlentdevs.xlentlearn.ui.dashboard.project

import android.os.Bundle
import android.text.Editable
import android.text.TextWatcher
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.activity.OnBackPressedCallback
import androidx.fragment.app.Fragment
import androidx.fragment.app.viewModels
import androidx.navigation.fragment.findNavController
import androidx.recyclerview.widget.RecyclerView
import com.google.android.material.bottomnavigation.BottomNavigationView
import com.xlentdevs.xlentlearn.R
import com.xlentdevs.xlentlearn.databinding.FragmentProjectBinding
import com.xlentdevs.xlentlearn.ui.dashboard.DashBoardActivity
import com.xlentdevs.xlentlearn.utils.showSnackBar

class ProjectFragment : Fragment() {

    private val viewModel: ProjectViewModel by viewModels {
        ProjectViewModelFactory(
            requireNotNull(this.activity).application,
        )
    }

    private lateinit var listAdapterProject: ProjectAdapter
    private lateinit var listAdapterObserverProject: RecyclerView.AdapterDataObserver

    private lateinit var binding: FragmentProjectBinding

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        // Inflate the layout for this fragment
        binding = FragmentProjectBinding.inflate(inflater, container, false)
        binding.lifecycleOwner = this
        binding.fragment = this
        binding.viewModel = viewModel

        setUpObservers()
        setupListAdapterProject()

        return binding.root
    }

    private fun setUpObservers() {
        viewModel.snackBarText.observe(viewLifecycleOwner, { text ->
            view?.showSnackBar(text, R.id.containerDashBoardActivity)
        })

        viewModel.dataLoading.observe(viewLifecycleOwner, { value ->
            (activity as DashBoardActivity).showGlobalProgressBar(value)
        })

        viewModel.isLoadingProject.observe(viewLifecycleOwner, { value ->
            if (value == true) binding.progressProject.visibility = View.VISIBLE
            else binding.progressProject.visibility = View.GONE
        })

        viewModel.searchBarText.observe(viewLifecycleOwner, {value ->
            viewModel.getQueryListProject(value.toString(), viewModel.projectList, viewModel.isLoadingProject)
        })
    }

    private fun setupListAdapterProject() {
        listAdapterObserverProject = (object : RecyclerView.AdapterDataObserver() {
            override fun onItemRangeInserted(positionStart: Int, itemCount: Int) {
                binding.recyclerView.scrollToPosition(positionStart)
            }
        })

        listAdapterProject =
            ProjectAdapter(viewModel, ProjectItemListener { project ->
                findNavController().navigate(
                    ProjectFragmentDirections.actionProjectFragmentToVideosFragment(
                        project.playlistLink
                    )
                )
            })

        listAdapterProject.registerAdapterDataObserver(listAdapterObserverProject)
        binding.recyclerView.adapter = listAdapterProject
    }
}
package com.xlentdevs.xlentlearn.commons

import android.graphics.Color
import android.graphics.LinearGradient
import android.graphics.Shader
import android.widget.ImageView
import android.widget.TextView
import androidx.databinding.BindingAdapter
import androidx.recyclerview.widget.RecyclerView
import com.bumptech.glide.Glide
import com.bumptech.glide.request.RequestOptions
import com.xlentdevs.xlentlearn.R
import com.xlentdevs.xlentlearn.data.db.entity.CourseDetails
import com.xlentdevs.xlentlearn.data.db.entity.Lesson
import com.xlentdevs.xlentlearn.data.db.entity.NotificationDetails
import com.xlentdevs.xlentlearn.data.db.entity.ProjectDetails
import com.xlentdevs.xlentlearn.data.model.PlaylistYtModel
import com.xlentdevs.xlentlearn.ui.dashboard.admin.admin_post.AdminPostAdapter
import com.xlentdevs.xlentlearn.ui.dashboard.course.CourseAdapter
import com.xlentdevs.xlentlearn.ui.dashboard.enrolled.EnrolledCourseAdapter
import com.xlentdevs.xlentlearn.ui.dashboard.home.HomeCoursesAdapter
import com.xlentdevs.xlentlearn.ui.dashboard.home.HomeProjectAdapter
import com.xlentdevs.xlentlearn.ui.dashboard.lessons.LessonsCourseAdapter
import com.xlentdevs.xlentlearn.ui.dashboard.notification.NotificationAdapter
import com.xlentdevs.xlentlearn.ui.dashboard.project.ProjectAdapter

@BindingAdapter("bind_image_url")
fun bindImageWithGlide(imageView: ImageView, url: String?) {
    when (url) {
        null -> Unit
        "" -> imageView.setBackgroundResource(R.drawable.ic_dummy_profile_24_selected)
        else -> Glide.with(imageView.context).load(url).apply(
            RequestOptions()
                .placeholder(R.drawable.loading_animation)
                .error(R.drawable.ic_broken_image_icon)
        ).into(imageView)
    }
}

@BindingAdapter("text_gradient_color")
fun textGradientColor(heading: TextView, color1: String, color2: String) {
    val paint = heading.paint
    val width = paint.measureText(heading.text.toString())
    val textShader: Shader = LinearGradient(
        0f, 0f, width, heading.textSize, intArrayOf(
            Color.parseColor(color1),
            Color.parseColor(color2),
        ), null, Shader.TileMode.REPEAT
    )

    heading.paint.setShader(textShader)
}

@BindingAdapter("bind_course_lesson_list")
fun bindCourseLessonList(listView: RecyclerView, items: List<Lesson>?) {
    items?.let {
        (listView.adapter as AdminPostAdapter).submitList(items)
    }
}

@BindingAdapter("bind_courses_list")
fun bindCoursesList(listView: RecyclerView, items: List<CourseDetails>?) {
    items?.let {
        (listView.adapter as CourseAdapter).submitList(items)
    }
}

@BindingAdapter("bind_courses_list_home")
fun bindCoursesListHome(listView: RecyclerView, items: List<CourseDetails>?) {
    items?.let {
        (listView.adapter as HomeCoursesAdapter).submitList(items)
    }
}

@BindingAdapter("bind_projects_list_home")
fun bindProjectsListHome(listView: RecyclerView, items: List<ProjectDetails>?) {
    items?.let {
        (listView.adapter as HomeProjectAdapter).submitList(items)
    }
}

@BindingAdapter("bind_lesson_list")
fun bindLessonList(listView: RecyclerView, items: List<PlaylistYtModel.PlaylistItem>?) {
    items.let {
        (listView.adapter as LessonsCourseAdapter).submitList(items)
    }
}

@BindingAdapter("bind_projects_list")
fun bindProjectsList(listView: RecyclerView, items: List<ProjectDetails>?) {
    items?.let {
        (listView.adapter as ProjectAdapter).submitList(items)
    }
}

@BindingAdapter("bind_notification_list")
fun bindNotificationList(listView: RecyclerView, items: List<NotificationDetails>?) {
    items?.let {
        (listView.adapter as NotificationAdapter).submitList(items)
    }
}

@BindingAdapter("bind_enrolled_course_list")
fun bindEnrolledCourseList(listView: RecyclerView, items: List<CourseDetails>?) {
    items?.let {
        (listView.adapter as EnrolledCourseAdapter).submitList(items)
    }
}


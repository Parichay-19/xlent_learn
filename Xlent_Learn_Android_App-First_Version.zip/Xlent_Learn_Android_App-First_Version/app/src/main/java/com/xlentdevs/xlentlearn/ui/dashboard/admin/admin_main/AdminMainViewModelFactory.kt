package com.xlentdevs.xlentlearn.ui.dashboard.admin.admin_main

import android.app.Application
import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider

class AdminMainViewModelFactory(
    private val application: Application
): ViewModelProvider.Factory {

    override fun <T : ViewModel> create(modelClass: Class<T>): T {
        if (modelClass.isAssignableFrom(AdminMainViewModel::class.java)){
            return AdminMainViewModel(application) as T
        }
        throw IllegalArgumentException("Unknown ViewModel !")
    }
}
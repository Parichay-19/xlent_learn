package com.xlentdevs.xlentlearn.ui.dashboard.home

import android.content.Context
import android.graphics.Point
import android.os.Bundle
import android.view.*
import android.widget.Toast
import androidx.fragment.app.Fragment
import androidx.fragment.app.viewModels
import androidx.navigation.fragment.findNavController
import androidx.recyclerview.widget.RecyclerView
import com.google.android.material.bottomnavigation.BottomNavigationView
import com.xlentdevs.xlentlearn.R
import com.xlentdevs.xlentlearn.databinding.HomeFragmentBinding
import com.xlentdevs.xlentlearn.ui.dashboard.DashBoardActivity
import com.xlentdevs.xlentlearn.utils.showSnackBar

class HomeFragment : Fragment() {

    private val viewModel: HomeViewModel by viewModels {
        HomeViewModelFactory(
            requireNotNull(this.activity).application,
        )
    }

    private lateinit var listAdapterCourse: HomeCoursesAdapter
    private lateinit var listAdapterObserverCourse: RecyclerView.AdapterDataObserver

    private lateinit var listAdapterProject: HomeProjectAdapter
    private lateinit var listAdapterObserverProject: RecyclerView.AdapterDataObserver

    private lateinit var binding: HomeFragmentBinding

    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        binding = HomeFragmentBinding.inflate(inflater, container, false)
        binding.lifecycleOwner = this
        binding.fragment = this
        binding.viewModel = viewModel

        setupListAdapterCourse()
        setupListAdapterProject()
        setUpObservers()

        return binding.root
    }

    private fun setUpObservers() {
        viewModel.snackBarText.observe(viewLifecycleOwner, { text ->
            view?.showSnackBar(text, R.id.containerDashBoardActivity)
        })

        viewModel.dataLoading.observe(viewLifecycleOwner, { value ->
            (activity as DashBoardActivity).showGlobalProgressBar(value)
        })

        viewModel.isLoadingCourse.observe(viewLifecycleOwner, { value ->
            if (value == true) binding.progressHomeCourses.visibility = View.VISIBLE
            else binding.progressHomeCourses.visibility = View.GONE
        })

        viewModel.isLoadingProject.observe(viewLifecycleOwner, { value ->
            if (value == true) binding.progressHomeProjects.visibility = View.VISIBLE
            else binding.progressHomeProjects.visibility = View.GONE
        })
    }

    fun getScreenWidth(): Int {
        val wm = activity?.getSystemService(Context.WINDOW_SERVICE) as WindowManager
        val display: Display = wm.defaultDisplay
        val size = Point()
        display.getSize(size)
        return size.x
    }

    private fun setupListAdapterCourse() {
        listAdapterObserverCourse = (object : RecyclerView.AdapterDataObserver() {
            override fun onItemRangeInserted(positionStart: Int, itemCount: Int) {
                binding.recyclerViewCourses.scrollToPosition(positionStart)
            }
        })

        listAdapterCourse =
            HomeCoursesAdapter(viewModel, getScreenWidth(), HomeCourseItemListener { course, type ->
                findNavController().navigate(
                    HomeFragmentDirections.actionHomeFragmentToLessonsFragment(
                        course.id,
                        type,
                        course.name,
                        course.thumbnail
                    )
                )
            })

        listAdapterCourse.registerAdapterDataObserver(listAdapterObserverCourse)
        binding.recyclerViewCourses.adapter = listAdapterCourse
    }

    private fun setupListAdapterProject() {
        listAdapterObserverProject = (object : RecyclerView.AdapterDataObserver() {
            override fun onItemRangeInserted(positionStart: Int, itemCount: Int) {
                binding.recyclerViewProjects.scrollToPosition(positionStart)
            }
        })

        listAdapterProject = HomeProjectAdapter(
            viewModel,
            getScreenWidth(),
            HomeProjectItemListener { project, type ->
                findNavController().navigate(
                    HomeFragmentDirections.actionHomeFragmentToVideosFragment(
                        project.playlistLink
                    )
                )
            })

        listAdapterProject.registerAdapterDataObserver(listAdapterObserverProject)
        binding.recyclerViewProjects.adapter = listAdapterProject
    }

    fun movetoCourseFragment(){
        findNavController().navigate(HomeFragmentDirections.actionHomeFragmentToCourseFragment())
        requireActivity().findViewById<BottomNavigationView>(R.id.bottom_nav).getMenu().getItem(1).setChecked(true)
    }

    fun movetoProjectFragment(){
        findNavController().navigate(HomeFragmentDirections.actionHomeFragmentToProjectFragment())
        requireActivity().findViewById<BottomNavigationView>(R.id.bottom_nav).getMenu().getItem(2).setChecked(true)
    }

    fun movetoNotificationFragment(){
        findNavController().navigate(HomeFragmentDirections.actionHomeFragmentToNotificationFragment())
    }
}
package com.xlentdevs.xlentlearn.ui.splashscreen.onboarding.frags

import android.graphics.Color
import android.graphics.LinearGradient
import android.graphics.Shader
import android.graphics.Shader.TileMode
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.fragment.app.Fragment
import androidx.viewpager2.widget.ViewPager2
import com.xlentdevs.xlentlearn.R
import com.xlentdevs.xlentlearn.commons.textGradientColor
import com.xlentdevs.xlentlearn.databinding.FragmentOnBoardOneBinding


class OnBoardOneFragment : Fragment() {

    private lateinit var binding: FragmentOnBoardOneBinding
    private lateinit var viewPager2: ViewPager2

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        // Inflate the layout for this fragment
        binding = FragmentOnBoardOneBinding.inflate(inflater, container, false)
        binding.lifecycleOwner = this
        binding.fragment = this

        viewPager2 = requireActivity().findViewById<ViewPager2>(R.id.viewPager)
        textGradientColor(binding.heading, "#00456B", "#73CDFF")

        return binding.root
    }

    fun nextBtn() {
        viewPager2.currentItem = 1
    }
}
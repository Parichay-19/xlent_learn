package com.xlentdevs.xlentlearn.ui.dashboard.notification

import android.app.Application
import androidx.lifecycle.MutableLiveData
import com.xlentdevs.xlentlearn.commons.DefaultViewModel
import com.xlentdevs.xlentlearn.data.Result
import com.xlentdevs.xlentlearn.data.db.entity.NotificationDetails
import com.xlentdevs.xlentlearn.data.db.entity.ProjectDetails
import com.xlentdevs.xlentlearn.data.db.remote.FirebaseReferenceValueObserver
import com.xlentdevs.xlentlearn.data.db.repository.RealTimeDataRepository
import com.xlentdevs.xlentlearn.utils.PreferenceStore
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job

class NotificationViewModel(
    application: Application
) : DefaultViewModel() {

    private val firebaseReferenceObserver = FirebaseReferenceValueObserver()
    private var realTimeDataRepository: RealTimeDataRepository
    var prefs: PreferenceStore

    private var viewModelJob = Job()
    private val uiScope = CoroutineScope(Dispatchers.Main + viewModelJob)

    //For Loading
    val isLoadingNotifications = MutableLiveData<Boolean>()

    var notificationList: MutableLiveData<List<NotificationDetails>> = MutableLiveData()

    init {
        realTimeDataRepository = RealTimeDataRepository(application)
        prefs = PreferenceStore(application)
        isLoadingNotifications.value = true
        getLists("notificationDetails", notificationList, isLoadingNotifications)
    }

    fun getLists(
        path: String,
        list: MutableLiveData<List<NotificationDetails>>,
        isLoading: MutableLiveData<Boolean>
    ) {
        realTimeDataRepository.loadAndObserveNotificationList(
            path,
            firebaseReferenceObserver
        ) { result: Result<MutableList<NotificationDetails>?> ->
            onResult(null, result)

            if (result is Result.Success) {
                list.value = result.data!!
            }
            isLoading.value = false
        }
    }
}
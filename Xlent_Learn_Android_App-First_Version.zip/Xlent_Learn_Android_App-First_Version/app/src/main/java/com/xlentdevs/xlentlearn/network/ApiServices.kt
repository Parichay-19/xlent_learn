package com.xlentdevs.xlentlearn.network

import com.xlentdevs.xlentlearn.data.model.PlaylistItemsModel
import com.xlentdevs.xlentlearn.data.model.PlaylistYtModel
import retrofit2.Call
import retrofit2.http.GET
import retrofit2.http.Query

interface ApiServices {

    @GET("playlists")
    fun getPlaylist(
        @Query("part") part: String,
        @Query("id") playlistId: String,
        @Query("maxResults") maxResults: String
    ) : Call<PlaylistYtModel>

    @GET("playlistItems")
    fun getPlaylistItems(
        @Query("part") part: String,
        @Query("playlistId") playlist: String,
        @Query("pageToken") pageToken: String?
    ) : Call<PlaylistItemsModel>
}
package com.xlentdevs.xlentlearn.ui.dashboard.admin.admin_main

import android.app.Activity
import android.content.Intent
import android.graphics.Color
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.activity.result.contract.ActivityResultContracts
import androidx.core.graphics.drawable.DrawableCompat
import androidx.fragment.app.Fragment
import androidx.fragment.app.viewModels
import androidx.navigation.fragment.findNavController
import com.xlentdevs.xlentlearn.R
import com.xlentdevs.xlentlearn.commons.bindImageWithGlide
import com.xlentdevs.xlentlearn.databinding.AdminMainPageFragmentBinding
import com.xlentdevs.xlentlearn.utils.convertFileToByteArray
import com.xlentdevs.xlentlearn.utils.showSnackBar

class AdminMainFragment : Fragment() {

    private val viewModel: AdminMainViewModel by viewModels {
        AdminMainViewModelFactory(
            requireNotNull(this.activity).application
        )
    }

    private lateinit var binding: AdminMainPageFragmentBinding

    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        binding = AdminMainPageFragmentBinding.inflate(inflater, container, false)
        binding.lifecycleOwner = this
        binding.fragment = this
        binding.viewModel = viewModel

        setObservers()

        return binding.root
    }

    private fun setObservers() {
        viewModel.snackBarText.observe(viewLifecycleOwner, { text ->
            view?.showSnackBar(text, R.id.containerDashBoardActivity)
        })

        viewModel.isSendingCourseData.observe(viewLifecycleOwner, {value ->
            if (value == true){
                binding.uploadingDataProgress.visibility = View.VISIBLE
            } else if (value == false){
                binding.uploadingDataProgress.visibility = View.GONE
            }
        })

        viewModel.isSendingProjectData.observe(viewLifecycleOwner, {value ->
            if (value == true){
                binding.uploadingDataProgress.visibility = View.VISIBLE
            } else if (value == false){
                binding.uploadingDataProgress.visibility = View.GONE
            }
        })

        viewModel.courseId.observe(viewLifecycleOwner, { value ->
            if (value != null) {
                moveToAdminPostFragment()
            }
        })

        viewModel.projectId.observe(viewLifecycleOwner, {value->
            if (value != null){
                moveToProfilePageFragment()
            }
        })

        viewModel.type.observe(viewLifecycleOwner, {type->
            if (type == "Course"){
                courseClick()
            } else{
                projectClick()
            }
        })
    }

    fun moveToAdminPostFragment() {
        findNavController().navigate(
            AdminMainFragmentDirections.actionAdminMainFragmentToAdminPostFragment(
                viewModel.courseId.value!!
            )
        )
    }

    private fun moveToProfilePageFragment() {
        findNavController().popBackStack(R.id.profileFragment, false)
    }

    fun startSelectImageIntent() {
        val selectImageIntent = Intent(Intent.ACTION_GET_CONTENT)
        selectImageIntent.type = "image/*"
        resultLauncher.launch(selectImageIntent)
    }

    var resultLauncher =
        registerForActivityResult(ActivityResultContracts.StartActivityForResult()) { result ->
            if (result.resultCode == Activity.RESULT_OK) {
                val data: Intent? = result.data
                data?.data.let { uri ->

                    if (viewModel.type.value == "Course"){
                        bindImageWithGlide(binding.imageInside, uri.toString())
                    } else{
                        bindImageWithGlide(binding.imageInsideProject, uri.toString())
                    }

                    convertFileToByteArray(requireContext(), uri!!).let {
                        viewModel.imageUri.value = it
                    }
                }
            }
        }

    fun projectClick() {
        binding.headingPage.text = "Upload Project"

        viewModel.typeTextAdmin.value = "Course"

        val projectBtn = binding.projectUpload.background

        DrawableCompat.setTint(projectBtn, Color.parseColor("#007CC1"))
        binding.projectUpload.background = projectBtn
        binding.projectUpload.setTextColor(Color.WHITE)

        val courseBtn = binding.courseUpload.background

        DrawableCompat.setTint(courseBtn, Color.parseColor("#E8E8E8"))
        binding.courseUpload.background = courseBtn
        binding.courseUpload.setTextColor(Color.BLACK)

        binding.projectSection.visibility = View.VISIBLE
        binding.coursesSection.visibility = View.GONE
    }

    fun courseClick() {
        binding.headingPage.text = "Upload Course"

        viewModel.typeTextAdmin.value = "Project"

        val projectBtn = binding.projectUpload.background

        DrawableCompat.setTint(projectBtn, Color.parseColor("#E8E8E8"))
        binding.projectUpload.background = projectBtn
        binding.projectUpload.setTextColor(Color.BLACK)

        val courseBtn = binding.courseUpload.background

        DrawableCompat.setTint(courseBtn, Color.parseColor("#007CC1"))
        binding.courseUpload.background = courseBtn
        binding.courseUpload.setTextColor(Color.WHITE)

        binding.projectSection.visibility = View.GONE
        binding.coursesSection.visibility = View.VISIBLE
    }
}
package com.xlentdevs.xlentlearn.ui.dashboard.home

import android.app.Application
import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import com.xlentdevs.xlentlearn.ui.dashboard.admin.admin_main.AdminMainViewModel

class HomeViewModelFactory(
    private val application: Application
): ViewModelProvider.Factory {

    override fun <T : ViewModel> create(modelClass: Class<T>): T {
        if (modelClass.isAssignableFrom(HomeViewModel::class.java)){
            return HomeViewModel(application) as T
        }
        throw IllegalArgumentException("Unknown ViewModel !")
    }
}
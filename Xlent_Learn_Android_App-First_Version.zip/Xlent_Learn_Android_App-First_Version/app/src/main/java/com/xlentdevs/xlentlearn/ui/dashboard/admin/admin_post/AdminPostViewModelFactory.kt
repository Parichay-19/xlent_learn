package com.xlentdevs.xlentlearn.ui.dashboard.admin.admin_post

import android.app.Application
import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import com.xlentdevs.xlentlearn.ui.dashboard.admin.admin_main.AdminMainViewModel

class AdminPostViewModelFactory(
    private val application: Application,
    private val playlistId: String
): ViewModelProvider.Factory {

    override fun <T : ViewModel> create(modelClass: Class<T>): T {
        if (modelClass.isAssignableFrom(AdminPostViewModel::class.java)){
            return AdminPostViewModel(application, playlistId) as T
        }
        throw IllegalArgumentException("Unknown ViewModel !")
    }
}
package com.xlentdevs.xlentlearn.data.db.entity

data class ProjectDetails(
    var id: String = "",
    var name: String = "",
    var thumbnail: String = "",
    var prereq: String = "",
    var category: String = "",
    var playlistLink: String = ""
)
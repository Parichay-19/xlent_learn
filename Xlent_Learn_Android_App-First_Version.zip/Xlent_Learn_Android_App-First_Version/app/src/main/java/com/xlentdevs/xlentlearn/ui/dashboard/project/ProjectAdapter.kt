package com.xlentdevs.xlentlearn.ui.dashboard.project

import android.view.LayoutInflater
import android.view.ViewGroup
import androidx.recyclerview.widget.DiffUtil
import androidx.recyclerview.widget.ListAdapter
import androidx.recyclerview.widget.RecyclerView
import com.xlentdevs.xlentlearn.data.db.entity.ProjectDetails
import com.xlentdevs.xlentlearn.databinding.ListItemProjectCardBinding

class ProjectAdapter internal constructor(
    private val viewModel: ProjectViewModel,
    val clickListener: ProjectItemListener
) : ListAdapter<ProjectDetails, RecyclerView.ViewHolder>(ProjectDiffCallback()) {

    class ProjectViewHolder(private val binding: ListItemProjectCardBinding) :
        RecyclerView.ViewHolder(binding.root) {
        fun bind(
            viewModel: ProjectViewModel,
            clickListener: ProjectItemListener,
            item: ProjectDetails
        ) {
            binding.viewModel = viewModel
            binding.projectDetails = item
            binding.clickListener = clickListener

            binding.executePendingBindings()
        }
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): RecyclerView.ViewHolder {
        val layoutInflater = LayoutInflater.from(parent.context)

        val binding = ListItemProjectCardBinding.inflate(layoutInflater, parent, false)

        return ProjectViewHolder(binding)
    }

    override fun onBindViewHolder(holder: RecyclerView.ViewHolder, position: Int) {
        (holder as ProjectViewHolder).bind(viewModel, clickListener, getItem(position))
    }

}

class ProjectDiffCallback : DiffUtil.ItemCallback<ProjectDetails>() {

    override fun areItemsTheSame(oldItem: ProjectDetails, newItem: ProjectDetails): Boolean {
        return oldItem == newItem
    }

    override fun areContentsTheSame(oldItem: ProjectDetails, newItem: ProjectDetails): Boolean {
        return oldItem.id == newItem.id
    }
}

class ProjectItemListener(val clickListener: (project: ProjectDetails) -> Unit) {
    fun onClick(project: ProjectDetails) = clickListener(project)
}
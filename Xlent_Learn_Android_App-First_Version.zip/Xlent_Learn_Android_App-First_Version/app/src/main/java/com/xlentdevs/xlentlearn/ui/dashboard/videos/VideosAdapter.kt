package com.xlentdevs.xlentlearn.ui.dashboard.videos

import android.view.LayoutInflater
import android.view.ViewGroup
import androidx.recyclerview.widget.DiffUtil
import androidx.recyclerview.widget.ListAdapter
import androidx.recyclerview.widget.RecyclerView
import com.xlentdevs.xlentlearn.data.model.PlaylistYtModel
import com.xlentdevs.xlentlearn.databinding.ListItemLessonVideoBinding

class VideosAdapter internal constructor(
    private val viewModel: VideosViewModel,
    val clickListener: VideosItemListener
) : ListAdapter<PlaylistYtModel.PlaylistItem, RecyclerView.ViewHolder>(VideosDiffCallback()){

    class VideosViewHolder(private val binding: ListItemLessonVideoBinding) :
        RecyclerView.ViewHolder(binding.root) {
        fun bind(
            viewModel: VideosViewModel,
            clickListener: VideosItemListener,
            position: Int,
            item: PlaylistYtModel.PlaylistItem
        ) {
            binding.viewModel = viewModel
            binding.clickListener = clickListener
            binding.playlistItem = item

            binding.executePendingBindings()
        }
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): RecyclerView.ViewHolder {
        val layoutInflater = LayoutInflater.from(parent.context)

        val binding = ListItemLessonVideoBinding.inflate(layoutInflater, parent, false)

        return VideosViewHolder(binding)
    }

    override fun onBindViewHolder(holder: RecyclerView.ViewHolder, position: Int) {
        (holder as VideosViewHolder).bind(viewModel, clickListener, position, getItem(position))
    }

}

class VideosDiffCallback : DiffUtil.ItemCallback<PlaylistYtModel.PlaylistItem>() {
    override fun areItemsTheSame(oldItem: PlaylistYtModel.PlaylistItem, newItem: PlaylistYtModel.PlaylistItem): Boolean {
        return oldItem == newItem
    }

    override fun areContentsTheSame(oldItem: PlaylistYtModel.PlaylistItem, newItem: PlaylistYtModel.PlaylistItem): Boolean {
        return oldItem.contentDetail.videoId == newItem.contentDetail.videoId
    }
}

class VideosItemListener(val clickListener: (video: PlaylistYtModel.PlaylistItem) -> Unit) {
    fun onClick(video: PlaylistYtModel.PlaylistItem) = clickListener(video)
}
package com.xlentdevs.xlentlearn.ui.dashboard.home

import android.view.LayoutInflater
import android.view.ViewGroup
import androidx.recyclerview.widget.DiffUtil
import androidx.recyclerview.widget.ListAdapter
import androidx.recyclerview.widget.RecyclerView
import com.xlentdevs.xlentlearn.data.db.entity.CourseDetails
import com.xlentdevs.xlentlearn.databinding.ListItemHomeCourseCardBinding


class HomeCoursesAdapter internal constructor(
    private val viewModel: HomeViewModel,
    private val screenWidth: Int,
    val clickListener: HomeCourseItemListener
) : ListAdapter<CourseDetails, RecyclerView.ViewHolder>(HomeCourseDiffCallback()){

    class HomeCourseViewHolder(private val binding: ListItemHomeCourseCardBinding) :
        RecyclerView.ViewHolder(binding.root) {
        fun bind(
            viewModel: HomeViewModel,
            screenWidth: Int,
            clickListener: HomeCourseItemListener,
            item: CourseDetails
        ) {
            binding.viewModel = viewModel
            binding.courseDetails = item
            binding.clickListener = clickListener
            binding.type = "courseLessons"

            itemView.getLayoutParams().width = ((screenWidth / 2)-60)

            binding.executePendingBindings()
        }
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): RecyclerView.ViewHolder {
        val layoutInflater = LayoutInflater.from(parent.context)

        val binding = ListItemHomeCourseCardBinding.inflate(layoutInflater, parent, false)

        return HomeCourseViewHolder(binding)
    }

    override fun onBindViewHolder(holder: RecyclerView.ViewHolder, position: Int) {
        (holder as HomeCourseViewHolder).bind(viewModel, screenWidth, clickListener, getItem(position))
    }

}

class HomeCourseDiffCallback : DiffUtil.ItemCallback<CourseDetails>() {
    override fun areItemsTheSame(oldItem: CourseDetails, newItem: CourseDetails): Boolean {
        return oldItem == newItem
    }

    override fun areContentsTheSame(oldItem: CourseDetails, newItem: CourseDetails): Boolean {
        return oldItem.id == newItem.id
    }
}

class HomeCourseItemListener(val clickListener: (course: CourseDetails, type: String) -> Unit) {
    fun onClick(course: CourseDetails, type: String) = clickListener(course, type)
}
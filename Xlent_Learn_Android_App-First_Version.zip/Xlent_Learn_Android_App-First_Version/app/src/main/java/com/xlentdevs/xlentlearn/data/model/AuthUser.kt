package com.xlentdevs.xlentlearn.data.model

data class AuthUser(
    val email: String,
    val password: String
)
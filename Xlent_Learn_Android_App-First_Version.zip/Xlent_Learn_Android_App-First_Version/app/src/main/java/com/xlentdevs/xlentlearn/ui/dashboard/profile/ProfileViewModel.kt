package com.xlentdevs.xlentlearn.ui.dashboard.profile

import android.app.Application
import androidx.lifecycle.LiveData
import androidx.lifecycle.MutableLiveData
import com.xlentdevs.xlentlearn.commons.DefaultViewModel
import com.xlentdevs.xlentlearn.data.db.entity.User
import com.xlentdevs.xlentlearn.data.db.repository.AuthAppRepository
import com.xlentdevs.xlentlearn.data.db.repository.RealTimeDataRepository
import com.xlentdevs.xlentlearn.utils.PreferenceStore
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.flow.collect
import kotlinx.coroutines.launch

class ProfileViewModel(
    application: Application
) : DefaultViewModel(){
    private var authAppRepository: AuthAppRepository
    private var realTimeDataRepository: RealTimeDataRepository
    private var prefs: PreferenceStore

    val userInfo: MutableLiveData<User> = MutableLiveData()

    private val _logout: MutableLiveData<Boolean> = MutableLiveData()
    val logout: LiveData<Boolean> = _logout

    private var viewModelJob = Job()
    private val uiScope = CoroutineScope(Dispatchers.Main + viewModelJob)

    init {
        authAppRepository = AuthAppRepository(application)
        realTimeDataRepository = RealTimeDataRepository(application)
        prefs = PreferenceStore(application)
        observeUserDetails()
    }

    fun observeUserDetails() {
        uiScope.launch {
            prefs.authToken.collect { user ->
                userInfo.value = user
            }
        }
    }

    fun LogOut() {
        authAppRepository.logoutUser()

        uiScope.launch {
            prefs.saveAuthToken("NA", "NA", "NA", "NA", false)
            _logout.value = true
        }
    }
}
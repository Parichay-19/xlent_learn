package com.xlentdevs.xlentlearn.ui.dashboard.notification

import android.app.Notification
import android.os.Bundle
import androidx.fragment.app.Fragment
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.fragment.app.viewModels
import androidx.navigation.fragment.findNavController
import androidx.recyclerview.widget.RecyclerView
import com.xlentdevs.xlentlearn.R
import com.xlentdevs.xlentlearn.databinding.FragmentNotificationBinding
import com.xlentdevs.xlentlearn.databinding.FragmentProjectBinding
import com.xlentdevs.xlentlearn.ui.dashboard.DashBoardActivity
import com.xlentdevs.xlentlearn.ui.dashboard.project.*
import com.xlentdevs.xlentlearn.utils.showSnackBar

class NotificationFragment : Fragment() {

    private val viewModel: NotificationViewModel by viewModels {
        NotificationViewModelFactory(
            requireNotNull(this.activity).application,
        )
    }

    private lateinit var listAdapterNotification: NotificationAdapter
    private lateinit var listAdapterObserverNotification: RecyclerView.AdapterDataObserver

    private lateinit var binding: FragmentNotificationBinding

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        binding = FragmentNotificationBinding.inflate(inflater, container, false)
        binding.lifecycleOwner = this
        binding.fragment = this
        binding.viewModel = viewModel

        setUpObservers()
        setupListAdapterProject()

        return binding.root
    }

    private fun setupListAdapterProject() {
        listAdapterObserverNotification = (object : RecyclerView.AdapterDataObserver() {
            override fun onItemRangeInserted(positionStart: Int, itemCount: Int) {
                binding.recyclerView.scrollToPosition(positionStart)
            }
        })

        listAdapterNotification =
            NotificationAdapter(viewModel, NotificationItemListener { project ->

            })

        listAdapterNotification.registerAdapterDataObserver(listAdapterObserverNotification)
        binding.recyclerView.adapter = listAdapterNotification
    }

    private fun setUpObservers() {
        viewModel.snackBarText.observe(viewLifecycleOwner, { text ->
            view?.showSnackBar(text, R.id.containerDashBoardActivity)
        })

        viewModel.dataLoading.observe(viewLifecycleOwner, { value ->
            (activity as DashBoardActivity).showGlobalProgressBar(value)
        })

        viewModel.isLoadingNotifications.observe(viewLifecycleOwner, { value ->
            if (value == true) binding.progressProject.visibility = View.VISIBLE
            else binding.progressProject.visibility = View.GONE
        })
    }
}
package com.xlentdevs.xlentlearn.ui.dashboard.course

import android.os.Bundle
import android.text.Editable
import android.text.TextWatcher
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.activity.OnBackPressedCallback
import androidx.fragment.app.Fragment
import androidx.fragment.app.viewModels
import androidx.navigation.fragment.findNavController
import androidx.recyclerview.widget.RecyclerView
import com.google.android.material.bottomnavigation.BottomNavigationView
import com.xlentdevs.xlentlearn.R
import com.xlentdevs.xlentlearn.databinding.FragmentCourseBinding
import com.xlentdevs.xlentlearn.ui.dashboard.DashBoardActivity
import com.xlentdevs.xlentlearn.utils.showSnackBar

class CourseFragment : Fragment() {

    private val viewModel: CourseViewModel by viewModels {
        CourseViewModelFactory(
            requireNotNull(this.activity).application,
        )
    }

    private lateinit var listAdapterCourse: CourseAdapter
    private lateinit var listAdapterObserverCourse: RecyclerView.AdapterDataObserver

    private lateinit var binding: FragmentCourseBinding

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        // Inflate the layout for this fragment
        binding = FragmentCourseBinding.inflate(inflater, container, false)
        binding.lifecycleOwner = this
        binding.fragment = this
        binding.viewModel = viewModel

        setUpObservers()
        setupListAdapterCourse()

        return binding.root
    }

    private fun setUpObservers() {
        viewModel.snackBarText.observe(viewLifecycleOwner, { text ->
            view?.showSnackBar(text, R.id.containerDashBoardActivity)
        })

        viewModel.dataLoading.observe(viewLifecycleOwner, { value ->
            (activity as DashBoardActivity).showGlobalProgressBar(value)
        })

        viewModel.isLoadingCourse.observe(viewLifecycleOwner, { value ->
            if (value == true) binding.progressCourse.visibility = View.VISIBLE
            else binding.progressCourse.visibility = View.GONE
        })

        viewModel.searchBarText.observe(viewLifecycleOwner, {value ->
            viewModel.getQueryListCourse(value.toString(), viewModel.coursesList, viewModel.isLoadingCourse)
        })
    }

    private fun setupListAdapterCourse() {
        listAdapterObserverCourse = (object : RecyclerView.AdapterDataObserver() {
            override fun onItemRangeInserted(positionStart: Int, itemCount: Int) {
                binding.recyclerView.scrollToPosition(positionStart)
            }
        })

        listAdapterCourse =
            CourseAdapter(viewModel, CourseItemListener { course, type ->
                viewModel.enrollCourse(course.id)

                findNavController().navigate(
                    CourseFragmentDirections.actionCourseFragmentToLessonsFragment(
                        course.id,
                        type,
                        course.name,
                        course.thumbnail
                    )
                )
            })

        listAdapterCourse.registerAdapterDataObserver(listAdapterObserverCourse)
        binding.recyclerView.adapter = listAdapterCourse
    }
}
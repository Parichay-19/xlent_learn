package com.xlentdevs.xlentlearn.ui.dashboard.enrolled

import android.view.LayoutInflater
import android.view.ViewGroup
import androidx.recyclerview.widget.DiffUtil
import androidx.recyclerview.widget.ListAdapter
import androidx.recyclerview.widget.RecyclerView
import com.xlentdevs.xlentlearn.data.db.entity.CourseDetails
import com.xlentdevs.xlentlearn.databinding.ListItemEnrolledCourseBinding

class EnrolledCourseAdapter internal constructor(
    private val viewModel: EnrolledCourseViewModel,
    val clickListener: EnrolledCourseItemListener
) : ListAdapter<CourseDetails, RecyclerView.ViewHolder>(EnrolledCourseDiffCallback()) {

    class EnrolledCourseViewHolder(private val binding: ListItemEnrolledCourseBinding) :
        RecyclerView.ViewHolder(binding.root) {
        fun bind(
            viewModel: EnrolledCourseViewModel,
            clickListener: EnrolledCourseItemListener,
            item: CourseDetails
        ) {
            binding.viewModel = viewModel
            binding.courseDetails = item
            binding.clickListener = clickListener
            binding.type = "courseLessons"

            binding.executePendingBindings()
        }
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): RecyclerView.ViewHolder {
        val layoutInflater = LayoutInflater.from(parent.context)

        val binding = ListItemEnrolledCourseBinding.inflate(layoutInflater, parent, false)

        return EnrolledCourseViewHolder(binding)
    }

    override fun onBindViewHolder(holder: RecyclerView.ViewHolder, position: Int) {
        (holder as EnrolledCourseViewHolder).bind(viewModel, clickListener, getItem(position))
    }

}

class EnrolledCourseDiffCallback : DiffUtil.ItemCallback<CourseDetails>() {

    override fun areItemsTheSame(
        oldItem: CourseDetails,
        newItem: CourseDetails
    ): Boolean {
        return oldItem == newItem
    }

    override fun areContentsTheSame(
        oldItem: CourseDetails,
        newItem: CourseDetails
    ): Boolean {
        return oldItem.id == newItem.id
    }
}

class EnrolledCourseItemListener(val clickListener: (course: CourseDetails, type: String) -> Unit) {
    fun onClick(course: CourseDetails, type: String) = clickListener(course, type)
}
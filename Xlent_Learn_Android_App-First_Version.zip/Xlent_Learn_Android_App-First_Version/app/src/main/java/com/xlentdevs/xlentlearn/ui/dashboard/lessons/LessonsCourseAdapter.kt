package com.xlentdevs.xlentlearn.ui.dashboard.lessons

import android.view.LayoutInflater
import android.view.ViewGroup
import androidx.recyclerview.widget.DiffUtil
import androidx.recyclerview.widget.ListAdapter
import androidx.recyclerview.widget.RecyclerView
import com.xlentdevs.xlentlearn.data.model.PlaylistYtModel
import com.xlentdevs.xlentlearn.databinding.ListItemCourseLessonBinding

class LessonsCourseAdapter internal constructor(
    private val viewModel: LessonsViewModel,
    val clickListener: LessonsItemListener
) : ListAdapter<PlaylistYtModel.PlaylistItem, RecyclerView.ViewHolder>(LessonsDiffCallback()){

    class LessonsViewHolder(private val binding: ListItemCourseLessonBinding) :
        RecyclerView.ViewHolder(binding.root) {
        fun bind(
            viewModel: LessonsViewModel,
            clickListener: LessonsItemListener,
            position: Int,
            item: PlaylistYtModel.PlaylistItem
        ) {
            binding.viewModel = viewModel
            binding.clickListener = clickListener
            binding.playListYtModelItem = item

            binding.lessonNumber.text = "Lesson " + (position+1)

            binding.executePendingBindings()
        }
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): RecyclerView.ViewHolder {
        val layoutInflater = LayoutInflater.from(parent.context)

        val binding = ListItemCourseLessonBinding.inflate(layoutInflater, parent, false)

        return LessonsViewHolder(binding)
    }

    override fun onBindViewHolder(holder: RecyclerView.ViewHolder, position: Int) {
        (holder as LessonsViewHolder).bind(viewModel, clickListener, position, getItem(position))
    }

}

class LessonsDiffCallback : DiffUtil.ItemCallback<PlaylistYtModel.PlaylistItem>() {
    override fun areItemsTheSame(oldItem: PlaylistYtModel.PlaylistItem, newItem: PlaylistYtModel.PlaylistItem): Boolean {
        return oldItem == newItem
    }

    override fun areContentsTheSame(oldItem: PlaylistYtModel.PlaylistItem, newItem: PlaylistYtModel.PlaylistItem): Boolean {
        return oldItem.id == newItem.id
    }
}

class LessonsItemListener(val clickListener: (lesson: PlaylistYtModel.PlaylistItem) -> Unit) {
    fun onClick(lesson: PlaylistYtModel.PlaylistItem) = clickListener(lesson)
}
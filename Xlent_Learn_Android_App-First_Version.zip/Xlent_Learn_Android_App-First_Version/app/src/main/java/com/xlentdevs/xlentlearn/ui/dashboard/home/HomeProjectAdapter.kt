package com.xlentdevs.xlentlearn.ui.dashboard.home

import android.view.LayoutInflater
import android.view.ViewGroup
import androidx.recyclerview.widget.DiffUtil
import androidx.recyclerview.widget.ListAdapter
import androidx.recyclerview.widget.RecyclerView
import com.xlentdevs.xlentlearn.data.db.entity.CourseDetails
import com.xlentdevs.xlentlearn.data.db.entity.ProjectDetails
import com.xlentdevs.xlentlearn.databinding.ListItemHomeProjectCardBinding

class HomeProjectAdapter internal constructor(
    private val viewModel: HomeViewModel,
    private val screenWidth: Int,
    val clickListener: HomeProjectItemListener
) : ListAdapter<ProjectDetails, RecyclerView.ViewHolder>(HomeProjectDiffCallback()){

    class HomeProjectViewHolder(private val binding: ListItemHomeProjectCardBinding) :
        RecyclerView.ViewHolder(binding.root) {
        fun bind(
            viewModel: HomeViewModel,
            screenWidth: Int,
            clickListener: HomeProjectItemListener,
            item: ProjectDetails
        ) {
            binding.viewModel = viewModel
            binding.projectDetails = item
            binding.clickListener = clickListener
            binding.type = "projectLessons"

            itemView.getLayoutParams().width = ((screenWidth / 2)-60)

            binding.executePendingBindings()
        }
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): RecyclerView.ViewHolder {
        val layoutInflater = LayoutInflater.from(parent.context)

        val binding = ListItemHomeProjectCardBinding.inflate(layoutInflater, parent, false)

        return HomeProjectViewHolder(binding)
    }

    override fun onBindViewHolder(holder: RecyclerView.ViewHolder, position: Int) {
        (holder as HomeProjectViewHolder).bind(viewModel, screenWidth, clickListener, getItem(position))
    }

}

class HomeProjectDiffCallback : DiffUtil.ItemCallback<ProjectDetails>() {
    override fun areItemsTheSame(oldItem: ProjectDetails, newItem: ProjectDetails): Boolean {
        return oldItem == newItem
    }

    override fun areContentsTheSame(oldItem: ProjectDetails, newItem: ProjectDetails): Boolean {
        return oldItem.id == newItem.id
    }
}

class HomeProjectItemListener(val clickListener: (course: ProjectDetails, type: String) -> Unit) {
    fun onClick(project: ProjectDetails, type: String) = clickListener(project, type)
}
package com.xlentdevs.xlentlearn.ui.dashboard.request

import android.os.Bundle
import androidx.fragment.app.Fragment
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.fragment.app.viewModels
import androidx.recyclerview.widget.RecyclerView
import com.xlentdevs.xlentlearn.R
import com.xlentdevs.xlentlearn.databinding.FragmentNotificationBinding
import com.xlentdevs.xlentlearn.databinding.FragmentRequestCourseBinding
import com.xlentdevs.xlentlearn.ui.dashboard.notification.NotificationAdapter
import com.xlentdevs.xlentlearn.ui.dashboard.notification.NotificationViewModel
import com.xlentdevs.xlentlearn.ui.dashboard.notification.NotificationViewModelFactory
import com.xlentdevs.xlentlearn.utils.showSnackBar

class RequestCourseFragment : Fragment() {

    private val viewModel: RequestCourseViewModel by viewModels {
        RequestCourseViewModelFactory(
            requireNotNull(this.activity).application,
        )
    }

    private lateinit var binding: FragmentRequestCourseBinding

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        // Inflate the layout for this fragment
        binding = FragmentRequestCourseBinding.inflate(inflater, container, false)
        binding.lifecycleOwner = this
        binding.fragment = this
        binding.viewModel = viewModel

        setUpObservers()

        return binding.root
    }

    private fun setUpObservers() {
        viewModel.snackBarText.observe(viewLifecycleOwner, { text ->
            view?.showSnackBar(text, R.id.containerDashBoardActivity)
        })

        viewModel.requestId.observe(viewLifecycleOwner, { text->
            viewModel.snackBarText.value = "Request Sent"
        })
    }
}
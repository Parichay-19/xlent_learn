package com.xlentdevs.xlentlearn.ui.dashboard.project

import android.app.Application
import androidx.lifecycle.MutableLiveData
import com.xlentdevs.xlentlearn.commons.DefaultViewModel
import com.xlentdevs.xlentlearn.data.Result
import com.xlentdevs.xlentlearn.data.db.entity.CourseDetails
import com.xlentdevs.xlentlearn.data.db.entity.ProjectDetails
import com.xlentdevs.xlentlearn.data.db.remote.FirebaseReferenceValueObserver
import com.xlentdevs.xlentlearn.data.db.repository.RealTimeDataRepository
import com.xlentdevs.xlentlearn.utils.PreferenceStore
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job

class ProjectViewModel(
    application: Application
) : DefaultViewModel() {

    private val firebaseReferenceObserver = FirebaseReferenceValueObserver()
    private var realTimeDataRepository: RealTimeDataRepository
    var prefs: PreferenceStore

    private var viewModelJob = Job()
    private val uiScope = CoroutineScope(Dispatchers.Main + viewModelJob)

    //For Loading
    val isLoadingProject = MutableLiveData<Boolean>()

    //Two Way Binding
    val searchBarText = MutableLiveData<String>()

    var projectList: MutableLiveData<List<ProjectDetails>> = MutableLiveData()

    init {
        realTimeDataRepository = RealTimeDataRepository(application)
        prefs = PreferenceStore(application)
        isLoadingProject.value = true
        getLists("projectDetails", projectList, isLoadingProject)
    }

    fun getLists(
        path: String,
        list: MutableLiveData<List<ProjectDetails>>,
        isLoading: MutableLiveData<Boolean>
    ) {
        realTimeDataRepository.loadAndObserveProjectList(
            path,
            firebaseReferenceObserver
        ) { result: Result<MutableList<ProjectDetails>?> ->
            onResult(null, result)

            if (result is Result.Success) {
                list.value = result.data!!
            }
            isLoading.value = false
        }
    }

    fun getQueryListProject(
        query: String,
        list: MutableLiveData<List<ProjectDetails>>,
        isLoading: MutableLiveData<Boolean>
    ) {
        realTimeDataRepository.queryAndLoadProjectList(
            query,
            firebaseReferenceObserver
        ) { result: Result<MutableList<ProjectDetails>?> ->
            onResult(null, result)

            if (result is Result.Success) {
                list.value = result.data!!
            }

            isLoading.value = false
        }
    }
}
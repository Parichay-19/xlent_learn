package com.xlentdevs.xlentlearn.ui.dashboard.lessons

import android.app.Application
import android.util.Log
import androidx.lifecycle.MutableLiveData
import com.xlentdevs.xlentlearn.commons.DefaultViewModel
import com.xlentdevs.xlentlearn.data.Result
import com.xlentdevs.xlentlearn.data.db.entity.Lesson
import com.xlentdevs.xlentlearn.data.db.remote.FirebaseReferenceValueObserver
import com.xlentdevs.xlentlearn.data.db.repository.RealTimeDataRepository
import com.xlentdevs.xlentlearn.data.model.PlaylistYtModel
import com.xlentdevs.xlentlearn.network.ApiConfig
import com.xlentdevs.xlentlearn.utils.PreferenceStore
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import retrofit2.Call
import retrofit2.Callback
import retrofit2.Response

class LessonsViewModel(
    application: Application,
    var courseId: String,
    var type: String,
    var name:String,
    var photo:String
): DefaultViewModel() {
    private val BASE_URL = "https://www.googleapis.com/youtube/v3/"

    private val firebaseReferenceObserver = FirebaseReferenceValueObserver()
    private var realTimeDataRepository: RealTimeDataRepository
    var prefs: PreferenceStore

    //For Loading
    val isLoading = MutableLiveData<Boolean>()

    private var viewModelJob = Job()
    private val uiScope = CoroutineScope(Dispatchers.Main + viewModelJob)

    var playlist: MutableLiveData<PlaylistYtModel> = MutableLiveData()

    var courseLessonList: MutableLiveData<List<Lesson>> = MutableLiveData()


    init {
        realTimeDataRepository = RealTimeDataRepository(application)
        prefs = PreferenceStore(application)
        getCourseLessonLists()
    }

    fun getCourseLessonLists() {
        isLoading.value = true
        realTimeDataRepository.loadAndObserveList(type, courseId ,firebaseReferenceObserver)
        { result: Result<MutableList<Lesson>?> ->
            onResult(null, result)

            if (result is Result.Success) {
                courseLessonList.value = result.data!!
                getPlaylistsFromCourseList(courseLessonList.value!!)
            }
        }
    }

    private fun getPlaylistsFromCourseList(value: List<Lesson>) {
        var playlistsString = ""
        for(playlistId in value){
            playlistsString = playlistsString + playlistId.id + ","
        }

        networkCallGetPlaylistDetails(playlistsString)
    }

    private fun networkCallGetPlaylistDetails(playlistId: String) {
        val client = ApiConfig
            .getService(BASE_URL)
            .getPlaylist(
                "snippet,contentDetails",
                playlistId,
                "10")
        client.enqueue(object : Callback<PlaylistYtModel> {
            override fun onResponse(
                call: Call<PlaylistYtModel>,
                response: Response<PlaylistYtModel>
            ) {
                if (response.isSuccessful){
                    val data = response.body()
                    if (data != null){
                        playlist.value = data!!
                        isLoading.value = false
                    }
                }
            }

            override fun onFailure(call: Call<PlaylistYtModel>, t: Throwable) {
                Log.e("Ajeet", "Failure: ", t)
                isLoading.value = false
            }
        })
    }
}
package com.xlentdevs.xlentlearn.ui.dashboard.admin.admin_notification

import android.os.Bundle
import androidx.fragment.app.Fragment
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Toast
import androidx.fragment.app.viewModels
import androidx.recyclerview.widget.RecyclerView
import com.google.firebase.messaging.FirebaseMessaging
import com.xlentdevs.xlentlearn.R
import com.xlentdevs.xlentlearn.databinding.AdminPostFragmentBinding
import com.xlentdevs.xlentlearn.databinding.FragmentAdminNotificationBinding
import com.xlentdevs.xlentlearn.notifications.NotificationData
import com.xlentdevs.xlentlearn.notifications.PushNotification
import com.xlentdevs.xlentlearn.notifications.RetrofitInstanceNotification
import com.xlentdevs.xlentlearn.ui.dashboard.admin.admin_post.AdminPostAdapter
import com.xlentdevs.xlentlearn.ui.dashboard.admin.admin_post.AdminPostViewModel
import com.xlentdevs.xlentlearn.ui.dashboard.admin.admin_post.AdminPostViewModelFactory
import com.xlentdevs.xlentlearn.utils.showSnackBar
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import java.lang.Exception


class AdminNotificationFragment : Fragment() {

    private val viewModel: AdminNotificationViewModel by viewModels {
        AdminNotificationViewModelFactory(
            requireNotNull(this.activity).application
        )
    }

    private lateinit var binding: FragmentAdminNotificationBinding

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        // Inflate the layout for this fragment
        binding = FragmentAdminNotificationBinding.inflate(inflater, container, false)
        binding.lifecycleOwner = this
        binding.fragment = this
        binding.viewModel = viewModel

        setUpObservers()

        return binding.root
    }

    private fun setUpObservers() {
        viewModel.snackBarText.observe(viewLifecycleOwner, { text ->
            view?.showSnackBar(text, R.id.containerDashBoardActivity)
        })

        viewModel.notificationId.observe(viewLifecycleOwner, { text ->
            viewModel.snackBarText.value = "Notification Sent"
        })
    }

}
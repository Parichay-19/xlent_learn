package com.xlentdevs.xlentlearn.ui.authentication

import androidx.fragment.app.Fragment
import androidx.fragment.app.FragmentManager
import androidx.fragment.app.FragmentPagerAdapter
import com.xlentdevs.xlentlearn.ui.authentication.login.LoginFragment
import com.xlentdevs.xlentlearn.ui.authentication.signup.SignUpFragment

class PagerAdapter(fm: FragmentManager) :
    FragmentPagerAdapter(fm) {
    override fun getItem(position: Int): Fragment {
        return when (position) {
            0 -> {
                SignUpFragment()
            }
            1 -> {
                LoginFragment()
            }
            else -> SignUpFragment()
        }
    }

    override fun getCount(): Int {
        return 2
    }
}
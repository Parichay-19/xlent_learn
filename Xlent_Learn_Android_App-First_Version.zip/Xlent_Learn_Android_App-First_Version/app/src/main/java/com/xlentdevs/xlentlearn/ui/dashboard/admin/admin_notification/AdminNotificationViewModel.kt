package com.xlentdevs.xlentlearn.ui.dashboard.admin.admin_notification

import android.app.Application
import androidx.lifecycle.MutableLiveData
import com.google.firebase.messaging.FirebaseMessaging
import com.xlentdevs.xlentlearn.commons.DefaultViewModel
import com.xlentdevs.xlentlearn.data.db.entity.NotificationDetails
import com.xlentdevs.xlentlearn.data.db.repository.RealTimeDataRepository
import com.xlentdevs.xlentlearn.notifications.NotificationData
import com.xlentdevs.xlentlearn.notifications.PushNotification
import com.xlentdevs.xlentlearn.notifications.RetrofitInstanceNotification
import com.xlentdevs.xlentlearn.utils.isTextValid
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import java.lang.Exception

const val TOPIC = "/topics/myTopic"

class AdminNotificationViewModel(
    application: Application
) : DefaultViewModel() {

    private var realTimeDataRepository: RealTimeDataRepository

    //Two way binding
    val titleNotif = MutableLiveData<String>()
    val descNotif = MutableLiveData<String>()

    val notificationId = MutableLiveData<String>()

    init {
        realTimeDataRepository = RealTimeDataRepository(application)
        FirebaseMessaging.getInstance().subscribeToTopic(TOPIC)
    }

    private fun sendNotification(notification: PushNotification) =
        CoroutineScope(Dispatchers.IO).launch {
            try {
                val response = RetrofitInstanceNotification.api.postNotification(notification)
            } catch (e: Exception) {

            }
        }

    fun sendNotificationBtnPressed() {
        if (!isTextValid(4, titleNotif.value)) {
            snackBarText.value = "Title is too short"
            return
        }

        if (!isTextValid(8, descNotif.value)) {
            snackBarText.value = "Description is too short"
            return
        }

        sendNotif()
    }

    fun sendNotif() {
        PushNotification(
            NotificationData(titleNotif.value.toString(), descNotif.value.toString()),
            TOPIC
        ).also {
            sendNotification(it)
        }

        val notificationDetails =
            NotificationDetails(
                "",
                "${titleNotif.value}",
                "${descNotif.value}"
            )

        notificationId.value = realTimeDataRepository.updateNotificationDetails(
            "notificationDetails",
            notificationDetails
        )

        titleNotif.value = ""
        descNotif.value = ""
    }
}
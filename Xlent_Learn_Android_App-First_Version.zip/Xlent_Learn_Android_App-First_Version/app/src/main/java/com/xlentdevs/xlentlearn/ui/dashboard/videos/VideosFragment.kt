package com.xlentdevs.xlentlearn.ui.dashboard.videos

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.AbsListView
import androidx.fragment.app.Fragment
import androidx.fragment.app.viewModels
import androidx.navigation.fragment.navArgs
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.google.android.material.bottomnavigation.BottomNavigationView
import com.pierfrancescosoffritti.androidyoutubeplayer.core.player.YouTubePlayer
import com.pierfrancescosoffritti.androidyoutubeplayer.core.player.listeners.AbstractYouTubePlayerListener
import com.pierfrancescosoffritti.androidyoutubeplayer.core.player.listeners.YouTubePlayerFullScreenListener
import com.pierfrancescosoffritti.androidyoutubeplayer.core.player.utils.YouTubePlayerTracker
import com.pierfrancescosoffritti.androidyoutubeplayer.core.ui.utils.FadeViewHelper
import com.xlentdevs.xlentlearn.R
import com.xlentdevs.xlentlearn.databinding.VideosFragmentBinding
import com.xlentdevs.xlentlearn.utils.showSnackBar


class VideosFragment : Fragment() {

    private val args: VideosFragmentArgs by navArgs()

    private val viewModel: VideosViewModel by viewModels {
        VideosViewModelFactory(
            requireNotNull(this.activity).application,
            args.playlistId!!
        )
    }

    private var youtubePlayer: YouTubePlayer? = null
    private var mTracker: YouTubePlayerTracker? = null

    private var isLoading = false
    private var isScroll = false

    private var currentItem = -1
    private var totalItem = -1
    private var scrollOutItem = -1

    private var isAllVideoLoaded = false
    private var isPlayingVideo = false

    private var onReadyPlayer = false

    private lateinit var listAdapter: VideosAdapter
    private lateinit var listAdapterObserver: RecyclerView.AdapterDataObserver
    private lateinit var binding: VideosFragmentBinding

    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        binding = VideosFragmentBinding.inflate(inflater, container, false)
        binding.lifecycleOwner = this
        binding.fragment = this
        binding.viewModel = viewModel

        InitializeYouTubePlayer()
        setupListAdapter()
        setUpScrollCheck()
        setUpObservers()

        return binding.root
    }

    fun videoForward() {
        if (onReadyPlayer == false) {
            viewModel.snackBarText.value = "Player is getting ready"
        } else {
            youtubePlayer!!.seekTo(mTracker!!.currentSecond.plus(10f))
        }
    }

    fun videoBackward() {
        if (onReadyPlayer == false) {
            viewModel.snackBarText.value = "Player is getting ready"
        } else {
            youtubePlayer!!.seekTo(mTracker!!.currentSecond.minus(10f))
        }
    }

    private fun InitializeYouTubePlayer() {
        val fadeViewForwardBtn = FadeViewHelper(binding.videoForward)
        val fadeViewBackwardBtn = FadeViewHelper(binding.videoBackward)

        lifecycle.addObserver(binding.youtubePlayer)
        mTracker = YouTubePlayerTracker()

        binding.youtubePlayer.addYouTubePlayerListener(object : AbstractYouTubePlayerListener() {
            override fun onReady(
                youTubePlayer: YouTubePlayer
            ) {
                onReadyPlayer = true
                youtubePlayer = youTubePlayer
                youTubePlayer.addListener(mTracker!!)
                youTubePlayer.addListener(fadeViewForwardBtn)
                youTubePlayer.addListener(fadeViewBackwardBtn)

                val videoId = viewModel.playlistItem.value!!.items.get(0).contentDetail.videoId
                youTubePlayer.loadVideo(videoId!!, 0f)
            }
        })

        binding.youtubePlayer.addFullScreenListener(object : YouTubePlayerFullScreenListener {
            override fun onYouTubePlayerEnterFullScreen() {
                binding.youtubePlayer.enterFullScreen()
                activity!!.findViewById<BottomNavigationView>(R.id.bottom_nav).visibility =
                    View.GONE
            }

            override fun onYouTubePlayerExitFullScreen() {
                binding.youtubePlayer.exitFullScreen()
                activity!!.findViewById<BottomNavigationView>(R.id.bottom_nav).visibility =
                    View.VISIBLE
            }
        })
    }

    private fun setUpObservers() {
        viewModel.playlistItem.observe(viewLifecycleOwner, { playlistItemModel ->
            playlistItemModel!!.items.let { list ->
                listAdapter.submitList(listAdapter.currentList + list)
            }

            if (!isPlayingVideo) {
                binding.videoTitleVideos.text = playlistItemModel.items.get(0).snippetYt.title
            }
        })

        viewModel.isAllItemLoaded.observe(viewLifecycleOwner, { value ->
            isAllVideoLoaded = value
            if (value) viewModel.snackBarText.value = "All videos has been loaded"
        })

        viewModel.isLoading.observe(viewLifecycleOwner, { value ->
            isLoading = value
            binding.progressBar.visibility = if (isLoading) View.VISIBLE else View.GONE
        })

        viewModel.snackBarText.observe(viewLifecycleOwner, { value ->
            view?.showSnackBar(value, R.id.containerDashBoardActivity)
        })
    }

    private fun setUpScrollCheck() {
        val manager = LinearLayoutManager(requireContext(), RecyclerView.VERTICAL, false)
        binding.recyclerViewVideos.layoutManager = manager

        binding.recyclerViewVideos.addOnScrollListener(object : RecyclerView.OnScrollListener() {

            override fun onScrollStateChanged(recyclerView: RecyclerView, newState: Int) {
                super.onScrollStateChanged(recyclerView, newState)
                if (newState == AbsListView.OnScrollListener.SCROLL_STATE_TOUCH_SCROLL) {
                    isScroll = true
                }
            }

            override fun onScrolled(recyclerView: RecyclerView, dx: Int, dy: Int) {
                super.onScrolled(recyclerView, dx, dy)

                currentItem = manager.childCount
                totalItem = manager.itemCount
                scrollOutItem = manager.findFirstVisibleItemPosition()

                if (isScroll && (currentItem + scrollOutItem == totalItem)) {
                    isScroll = false
                    if (!isLoading) {
                        if (!isAllVideoLoaded) {
                            val playlistId = args.playlistId
                            playlistId?.let { viewModel.getPlaylistItems(it) }
                        } else {
                            viewModel.snackBarText.value = "All Videos Loaded"
                        }
                    }
                }
            }

        })
    }

    private fun setupListAdapter() {
        listAdapterObserver = (object : RecyclerView.AdapterDataObserver() {
            override fun onItemRangeInserted(positionStart: Int, itemCount: Int) {
                binding.recyclerViewVideos.scrollToPosition(positionStart)
            }
        })

        listAdapter = VideosAdapter(viewModel, VideosItemListener { video ->
            if (onReadyPlayer == false) {
                viewModel.snackBarText.value = "Player is getting ready"
            } else {
                youtubePlayer!!.loadVideo(video.contentDetail.videoId!!, 0f)
                binding.videoTitleVideos.text = video.snippetYt.title
            }
        })

        listAdapter.registerAdapterDataObserver(listAdapterObserver)
        binding.recyclerViewVideos.adapter = listAdapter
    }
}
package com.xlentdevs.xlentlearn.ui.dashboard.admin.admin_post

import android.app.Application
import android.util.Log
import androidx.lifecycle.MutableLiveData
import com.xlentdevs.xlentlearn.commons.DefaultViewModel
import com.xlentdevs.xlentlearn.data.Result
import com.xlentdevs.xlentlearn.data.db.entity.Lesson
import com.xlentdevs.xlentlearn.data.db.remote.FirebaseReferenceValueObserver
import com.xlentdevs.xlentlearn.data.db.repository.RealTimeDataRepository
import com.xlentdevs.xlentlearn.utils.PreferenceStore
import com.xlentdevs.xlentlearn.utils.isTextValid
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job

class AdminPostViewModel(
    application: Application,
    var playlistId: String
): DefaultViewModel() {
    private val firebaseReferenceObserver = FirebaseReferenceValueObserver()
    private var realTimeDataRepository: RealTimeDataRepository
    var prefs: PreferenceStore

    private var viewModelJob = Job()
    private val uiScope = CoroutineScope(Dispatchers.Main + viewModelJob)

    val isSendingData = MutableLiveData<Boolean>()
    val isDone = MutableLiveData<Boolean>()

    var courseLessonList: MutableLiveData<List<Lesson>> = MutableLiveData()

    //Two way Binding with edit text of SignUp page
    val playlistIdAdmin = MutableLiveData<String>()

    init {
        realTimeDataRepository = RealTimeDataRepository(application)
        prefs = PreferenceStore(application)
        getCourseLessonLists()
    }

    fun addButtonPressed(){
        if (!isTextValid(5, playlistIdAdmin.value)) {
            snackBarText.value = "Id text is too short"
            return
        }

        sendDataAndGoBackToProfilePage()
    }

    private fun sendDataAndGoBackToProfilePage() {
        isSendingData.value = true

            realTimeDataRepository.updateCourseLessons(
                "courseLessons",
                playlistIdAdmin.value!!,
                playlistId
            )
//        } else{
//            realTimeDataRepository.updateCourseLessons(
//                "projectLessons",
//                playlistIdAdmin.value!!,
//                playlistId
//            )
//        }
        playlistIdAdmin.value = ""
    }

    fun submitButtonPressed(){
        isDone.value = true
    }

    fun getCourseLessonLists() {

            realTimeDataRepository.loadAndObserveList(
                "courseLessons",
                playlistId,
                firebaseReferenceObserver
            )
            { result: Result<MutableList<Lesson>?> ->
                onResult(null, result)

                if (result is Result.Success) {
                    courseLessonList.value = result.data!!
                }
            }
//        } else{
//            realTimeDataRepository.loadAndObserveList(
//                "projectLessons",
//                playlistId,
//                firebaseReferenceObserver
//            )
//            { result: Result<MutableList<Lesson>?> ->
//                onResult(null, result)
//
//                if (result is Result.Success) {
//                    courseLessonList.value = result.data!!
//                }
//            }
//        }
    }
}
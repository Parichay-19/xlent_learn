package com.xlentdevs.xlentlearn.ui.dashboard.request

import android.app.Application
import androidx.lifecycle.MutableLiveData
import com.google.firebase.messaging.FirebaseMessaging
import com.xlentdevs.xlentlearn.commons.DefaultViewModel
import com.xlentdevs.xlentlearn.data.db.entity.NotificationDetails
import com.xlentdevs.xlentlearn.data.db.entity.RequestDetails
import com.xlentdevs.xlentlearn.data.db.repository.RealTimeDataRepository
import com.xlentdevs.xlentlearn.ui.dashboard.admin.admin_notification.TOPIC
import com.xlentdevs.xlentlearn.utils.isTextValid

class RequestCourseViewModel(
    application: Application
): DefaultViewModel() {

    private var realTimeDataRepository: RealTimeDataRepository

    //Two way binding
    val titleRequest = MutableLiveData<String>()
    val descRequest = MutableLiveData<String>()

    val requestId = MutableLiveData<String>()

    init {
        realTimeDataRepository = RealTimeDataRepository(application)
    }

    fun sendRequestBtnPressed() {
        if (!isTextValid(4, titleRequest.value)) {
            snackBarText.value = "Title is too short"
            return
        }

        if (!isTextValid(8, descRequest.value)) {
            snackBarText.value = "Description is too short"
            return
        }

        sendRequest()
    }

    private fun sendRequest() {
        val requestDetails =
            RequestDetails(
                "",
                "${titleRequest.value}",
                "${descRequest.value}"
            )

        requestId.value = realTimeDataRepository.updateNewCourseRequest(
            "requestDetails",
            requestDetails
        )

        titleRequest.value = ""
        descRequest.value = ""
    }
}
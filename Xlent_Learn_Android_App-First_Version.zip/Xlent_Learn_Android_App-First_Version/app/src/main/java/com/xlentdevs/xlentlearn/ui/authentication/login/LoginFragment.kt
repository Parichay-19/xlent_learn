package com.xlentdevs.xlentlearn.ui.authentication.login

import android.app.Activity
import android.content.Intent
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.activity.result.contract.ActivityResultContracts
import androidx.fragment.app.Fragment
import androidx.fragment.app.viewModels
import com.google.android.gms.auth.api.signin.GoogleSignIn
import com.google.android.gms.auth.api.signin.GoogleSignInClient
import com.google.android.gms.auth.api.signin.GoogleSignInOptions
import com.google.android.gms.common.api.ApiException
import com.google.android.gms.tasks.OnCompleteListener
import com.google.firebase.auth.GoogleAuthProvider
import com.google.firebase.database.DataSnapshot
import com.google.firebase.database.DatabaseError
import com.google.firebase.database.ValueEventListener
import com.google.firebase.database.ktx.database
import com.google.firebase.ktx.Firebase
import com.xlentdevs.xlentlearn.R
import com.xlentdevs.xlentlearn.databinding.LoginFragmentBinding
import com.xlentdevs.xlentlearn.ui.authentication.MainActivity
import com.xlentdevs.xlentlearn.ui.dashboard.DashBoardActivity
import com.xlentdevs.xlentlearn.utils.showSnackBar

class LoginFragment : Fragment() {

    private val viewModel: LoginViewModel by viewModels {
        LoginViewModelFactory(
            requireNotNull(this.activity).application
        )
    }

    private lateinit var binding: LoginFragmentBinding
    private lateinit var googleLoginClient: GoogleSignInClient

    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        binding = LoginFragmentBinding.inflate(inflater, container, false)
        binding.lifecycleOwner = this
        binding.fragment = this
        binding.viewModel = viewModel

        initGoogleSignInClient()
        setObservers()

        return binding.root

    }

    fun moveToSignUpPage() {

    }

    private fun setObservers() {
        viewModel.snackBarText.observe(viewLifecycleOwner, { text ->
            view?.showSnackBar(text, R.id.containerMainActivity)
        })

        viewModel.dataLoading.observe(viewLifecycleOwner, { value ->
            (activity as MainActivity).showGlobalProgressBar(value)
        })

        viewModel.isLoggedIn.observe(viewLifecycleOwner, { user ->
            if (user != null) {
                moveToDashboardScreen()
            }
        })
    }

    private fun moveToDashboardScreen() {
        val intent = Intent(context, DashBoardActivity::class.java)
        startActivity(intent)
        (activity as MainActivity).finish()
    }
    //-------------------------Google Login code starts---------------------------

    private fun initGoogleSignInClient() {
        val gso = GoogleSignInOptions.Builder(GoogleSignInOptions.DEFAULT_SIGN_IN)
            .requestIdToken(resources.getString(R.string.default_web_client_id))
            .requestEmail()
            .build()

        googleLoginClient = GoogleSignIn.getClient(requireContext(), gso)
    }

    fun loginUsingGoogle() {
        val signInGoogleIntent = googleLoginClient.signInIntent
        resultLauncher.launch(signInGoogleIntent)
    }

    private var resultLauncher =
        registerForActivityResult(ActivityResultContracts.StartActivityForResult()) { result ->
            if (result.resultCode == Activity.RESULT_OK) {
                // There are no request codes
                val data: Intent? = result.data

                val task = GoogleSignIn.getSignedInAccountFromIntent(data)
                try {
                    val account = task.getResult(ApiException::class.java)!!

                    Firebase.database.reference.child("users").orderByChild("email")
                        .startAt(account.email).endAt(account.email + "\uF8FF")
                        .addValueEventListener(object : ValueEventListener {
                            override fun onDataChange(snapshot: DataSnapshot) {
                                if (snapshot.exists()) {
                                    viewModel.dataLoading.value = true
                                    getGoogleAuthCredential(account.idToken!!)
                                } else {
                                    viewModel.snackBarText.value = "User Doesn't Exist"
                                    googleLoginClient.signOut()
                                }
                            }

                            override fun onCancelled(error: DatabaseError) {
                                viewModel.snackBarText.value = "Try Again !"
                            }
                        })
                } catch (e: ApiException) {
                    viewModel.snackBarText.value = "Unknown Error, Try Again !"
                }
            }
        }

    private fun getGoogleAuthCredential(idToken: String) {
        val googleAuthCredential = GoogleAuthProvider.getCredential(idToken, null)
        googleLoginClient.signOut().addOnCompleteListener(OnCompleteListener {
            viewModel.googleLogin(googleAuthCredential)
        })
    }
    //------------------------------Google Login code ends-----------------------------
}
package com.xlentdevs.xlentlearn.ui.authentication

import android.os.Bundle
import android.view.View
import androidx.appcompat.app.AppCompatActivity
import androidx.databinding.DataBindingUtil
import androidx.viewpager.widget.ViewPager
import androidx.viewpager2.widget.ViewPager2
import com.xlentdevs.xlentlearn.R
import com.xlentdevs.xlentlearn.databinding.ActivityMainBinding

class MainActivity : AppCompatActivity() {

    lateinit var binding: ActivityMainBinding

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        binding = DataBindingUtil.setContentView(this, R.layout.activity_main)

        binding.SignUpBtn.setOnClickListener {
            binding.ViewPager.currentItem = 0
        }

        binding.LoginBtn.setOnClickListener {
            binding.ViewPager.currentItem = 1
        }

        binding.ViewPager.addOnPageChangeListener(object : ViewPager.OnPageChangeListener{
            override fun onPageScrolled(
                position: Int,
                positionOffset: Float,
                positionOffsetPixels: Int
            ) {

            }

            override fun onPageSelected(position: Int) {
                if (position == 0){
                    binding.SignUpText.setTextColor(resources.getColor(R.color.light_blue))
                    binding.SignUpLineView.visibility = View.VISIBLE

                    binding.LoginText.setTextColor(resources.getColor(R.color.grey))
                    binding.LoginLineView.visibility = View.GONE
                }

                if (position == 1){
                    binding.LoginText.setTextColor(resources.getColor(R.color.light_blue))
                    binding.LoginLineView.visibility = View.VISIBLE

                    binding.SignUpText.setTextColor(resources.getColor(R.color.grey))
                    binding.SignUpLineView.visibility = View.GONE
                }
            }

            override fun onPageScrollStateChanged(state: Int) {

            }
        })

        val pagerAdapter = PagerAdapter(supportFragmentManager)
        binding.ViewPager.adapter = pagerAdapter
    }

    fun showGlobalProgressBar(show: Boolean) {
        if (show) binding.mainProgressBar.visibility = View.VISIBLE
        else binding.mainProgressBar.visibility = View.GONE
    }
}
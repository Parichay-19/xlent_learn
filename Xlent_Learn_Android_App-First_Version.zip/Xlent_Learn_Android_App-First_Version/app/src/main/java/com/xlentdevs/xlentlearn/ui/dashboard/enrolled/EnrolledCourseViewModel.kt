package com.xlentdevs.xlentlearn.ui.dashboard.enrolled

import android.app.Application
import androidx.lifecycle.MutableLiveData
import com.xlentdevs.xlentlearn.commons.DefaultViewModel
import com.xlentdevs.xlentlearn.data.Result
import com.xlentdevs.xlentlearn.data.db.entity.CourseDetails
import com.xlentdevs.xlentlearn.data.db.entity.User
import com.xlentdevs.xlentlearn.data.db.remote.FirebaseReferenceValueObserver
import com.xlentdevs.xlentlearn.data.db.repository.RealTimeDataRepository
import com.xlentdevs.xlentlearn.utils.PreferenceStore
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.flow.collect
import kotlinx.coroutines.launch

class EnrolledCourseViewModel(
    application: Application
) : DefaultViewModel() {

    private val firebaseReferenceObserver = FirebaseReferenceValueObserver()
    private var realTimeDataRepository: RealTimeDataRepository
    var prefs: PreferenceStore

    private var viewModelJob = Job()
    private val uiScope = CoroutineScope(Dispatchers.Main + viewModelJob)

    val userInfo: MutableLiveData<User> = MutableLiveData()
    val arrayList: MutableList<CourseDetails> = arrayListOf()

    //For Loading
    val isLoadingEnrolledCourses = MutableLiveData<Boolean>()

    var enrolledCoursesIdList: MutableLiveData<List<String>> = MutableLiveData()
    var enrolledCoursesList: MutableLiveData<List<CourseDetails>> = MutableLiveData()

    init {
        realTimeDataRepository = RealTimeDataRepository(application)
        prefs = PreferenceStore(application)
        isLoadingEnrolledCourses.value = true
        observeUserDetails()
    }

    fun observeUserDetails() {
        uiScope.launch {
            prefs.authToken.collect { user ->
                userInfo.value = user
                getCoursesIdList("users", userInfo.value!!.uid, enrolledCoursesIdList)
            }
        }
    }

    fun getCoursesIdList(
        path: String,
        userId: String,
        list: MutableLiveData<List<String>>
    ) {
        realTimeDataRepository.loadAndObserveEnrolledCourseIdList(
            path,
            userId,
            firebaseReferenceObserver
        ) { result: Result<MutableList<String>> ->
            onResult(null, result)

            if (result is Result.Success) {
                list.value = result.data!!
                for (id in enrolledCoursesIdList.value!!) {
                    getCourseList(id)
                }
                isLoadingEnrolledCourses.value = false
            }
        }
    }

    fun getCourseList(id: String) {
        realTimeDataRepository.loadAndObserveEnrolledCourse(
            "courseDetails",
            id,
            firebaseReferenceObserver
        )
        { result: Result<CourseDetails> ->
            onResult(null, result)
            if (result is Result.Success) {
                arrayList.add(result.data!!)
                enrolledCoursesList.value = arrayList
            }
        }
    }
}
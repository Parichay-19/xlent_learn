package com.xlentdevs.xlentlearn.ui.dashboard.profile

import android.content.Intent
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.fragment.app.Fragment
import androidx.fragment.app.viewModels
import androidx.navigation.fragment.findNavController
import com.xlentdevs.xlentlearn.databinding.ProfileFragmentBinding
import com.xlentdevs.xlentlearn.ui.authentication.MainActivity
import com.xlentdevs.xlentlearn.ui.dashboard.DashBoardActivity

class ProfileFragment : Fragment() {

    private val viewModel: ProfileViewModel by viewModels {
        ProfileViewModelFactory(
            requireNotNull(this.activity).application
        )
    }

    private lateinit var binding: ProfileFragmentBinding

    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        binding = ProfileFragmentBinding.inflate(inflater, container, false)
        binding.lifecycleOwner = this
        binding.fragment = this
        binding.viewModel = viewModel

        setObservers()

        return binding.root
    }

    private fun setObservers() {
        viewModel.logout.observe(viewLifecycleOwner, { value ->
            if (value == true) {
                val intent = Intent(context, MainActivity::class.java)
                startActivity(intent)
                (activity as DashBoardActivity).finish()
            }
        })
    }

    fun moveToAdminMainPage() {
        findNavController().navigate(ProfileFragmentDirections.actionProfileFragmentToAdminMainFragment())
    }

    fun moveToNotificationPage() {
        findNavController().navigate(ProfileFragmentDirections.actionProfileFragmentToAdminNotificationFragment())
    }

    fun moveToEnrolledCoursePage() {
        findNavController().navigate(ProfileFragmentDirections.actionProfileFragmentToEnrolledCourseFragment())
    }

    fun moveToRequestCourse() {
        findNavController().navigate(ProfileFragmentDirections.actionProfileFragmentToRequestCourseFragment())
    }
}
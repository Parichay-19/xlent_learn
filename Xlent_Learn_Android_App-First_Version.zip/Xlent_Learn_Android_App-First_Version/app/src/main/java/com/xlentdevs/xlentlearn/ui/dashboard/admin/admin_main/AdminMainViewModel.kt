package com.xlentdevs.xlentlearn.ui.dashboard.admin.admin_main

import android.app.Application
import android.net.Uri
import androidx.lifecycle.MutableLiveData
import com.xlentdevs.xlentlearn.commons.DefaultViewModel
import com.xlentdevs.xlentlearn.data.db.entity.CourseDetails
import com.xlentdevs.xlentlearn.data.db.entity.ProjectDetails
import com.xlentdevs.xlentlearn.data.db.repository.AuthAppRepository
import com.xlentdevs.xlentlearn.data.db.repository.RealTimeDataRepository
import com.xlentdevs.xlentlearn.data.db.repository.StorageRepository
import com.xlentdevs.xlentlearn.utils.PreferenceStore
import com.xlentdevs.xlentlearn.utils.isTextValid
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import com.xlentdevs.xlentlearn.data.Result
import com.xlentdevs.xlentlearn.data.db.entity.NotificationDetails

class AdminMainViewModel(
    application: Application
) : DefaultViewModel() {
    private var authAppRepository: AuthAppRepository
    private var realTimeDataRepository: RealTimeDataRepository
    private var storageRepository = StorageRepository()
    var prefs: PreferenceStore

    //For Data Uploading Flow
    val isSendingCourseData = MutableLiveData<Boolean>()
    val isSendingProjectData = MutableLiveData<Boolean>()

    val courseId = MutableLiveData<String>()
    val projectId = MutableLiveData<String>()
    val notificationId = MutableLiveData<String>()

    val type = MutableLiveData<String>()
    val imageUri = MutableLiveData<ByteArray>()

    //Common Two Way Binding
    val typeTextAdmin = MutableLiveData<String>()

    //Two way Binding with edit text for Course
    val nameTextCourseAdmin = MutableLiveData<String>()
    val thumbnailLinkCourseAdmin = MutableLiveData<String>()
    val skillsCoveredCourseAdmin = MutableLiveData<String>()
    val categoryCourseAdmin = MutableLiveData<String>()

    //Two way Binding with edit text for Project
    val nameTextProjectAdmin = MutableLiveData<String>()
    val thumbnailLinkProjectAdmin = MutableLiveData<String>()
    val preReqProjectAdmin = MutableLiveData<String>()
    val categoryProjectAdmin = MutableLiveData<String>()
    val playlistLinkProjectAdmin = MutableLiveData<String>()

    private var viewModelJob = Job()
    private val uiScope = CoroutineScope(Dispatchers.Main + viewModelJob)

    init {
        authAppRepository = AuthAppRepository(application)
        realTimeDataRepository = RealTimeDataRepository(application)
        storageRepository = StorageRepository()
        prefs = PreferenceStore(application)
        type.value = "Course"
    }

    fun nextButtonCoursePressed() {
        if (!isTextValid(5, nameTextCourseAdmin.value)) {
            snackBarText.value = "Name text is too short"
            return
        }

        if (!isTextValid(2, imageUri.value.toString())) {
            snackBarText.value = "Please select a image"
            return
        }

        if (!isTextValid(5, categoryCourseAdmin.value)) {
            snackBarText.value = "Category text is too short"
            return
        }

        if (!isTextValid(5, skillsCoveredCourseAdmin.value)) {
            snackBarText.value = "Skills Covered text is too short"
            return
        }

        if (imageUri.value == null) {
            snackBarText.value = "Choose a Image first"
            return
        }

        isSendingCourseData.value = true
        imageUri.value?.let { uploadCourseImage(it) }
    }

    fun uploadCourseImage(byteArray: ByteArray) {

        storageRepository.uploadCourseImage(
            nameTextCourseAdmin.value.toString(),
            byteArray
        ) { result: Result<Uri> ->
            onResult(null, result)
            if (result is Result.Success) {
                thumbnailLinkCourseAdmin.value = result.data.toString()
                sendCourseDataAndGoToNextPage()
            }
        }
    }

    private fun sendCourseDataAndGoToNextPage() {
        val courseDetails =
            CourseDetails(
                "",
                nameTextCourseAdmin.value!!,
                thumbnailLinkCourseAdmin.value!!,
                skillsCoveredCourseAdmin.value!!,
                categoryCourseAdmin.value!!
            )

        val notificationDetails =
            NotificationDetails(
                "",
                "${courseDetails.name} course is updated !",
                "Course covers ${courseDetails.skills}, check out in the course section"
            )

        isSendingCourseData.value = false

        notificationId.value = realTimeDataRepository.updateNotificationDetails(
            "notificationDetails",
            notificationDetails
        )

        courseId.value = realTimeDataRepository.updateNewCourse("courseDetails", courseDetails)
    }

    fun nextButtonProjectPressed() {
        if (!isTextValid(5, nameTextProjectAdmin.value)) {
            snackBarText.value = "Name text is too short"
            return
        }

        if (!isTextValid(5, categoryProjectAdmin.value)) {
            snackBarText.value = "Category text is too short"
            return
        }

        if (!isTextValid(5, preReqProjectAdmin.value)) {
            snackBarText.value = "Pre-Requisites text is too short"
            return
        }

        if (!isTextValid(5, playlistLinkProjectAdmin.value)) {
            snackBarText.value = "The Link is invalid"
        }

        if (imageUri.value == null) {
            snackBarText.value = "Choose a Image first"
            return
        }


        isSendingProjectData.value = true
        imageUri.value?.let { uploadProjectImage(it) }
    }

    fun uploadProjectImage(byteArray: ByteArray) {

        storageRepository.uploadProjectImage(
            nameTextProjectAdmin.value.toString(),
            byteArray
        ) { result: Result<Uri> ->
            onResult(null, result)
            if (result is Result.Success) {
                thumbnailLinkProjectAdmin.value = result.data.toString()
                sendProjectData()
            }
        }
    }

    private fun sendProjectData() {
        val projectDetails =
            ProjectDetails(
                "",
                nameTextProjectAdmin.value!!,
                thumbnailLinkProjectAdmin.value!!,
                preReqProjectAdmin.value!!,
                categoryProjectAdmin.value!!,
                playlistLinkProjectAdmin.value!!
            )

        val notificationDetails =
            NotificationDetails(
                "",
                "${projectDetails.name} project is updated !",
                "Prior knowledge of ${projectDetails.prereq} is expected, check out in the project section"
            )

        isSendingProjectData.value = false

        notificationId.value = realTimeDataRepository.updateNotificationDetails(
            "notificationDetails",
            notificationDetails
        )
        projectId.value = realTimeDataRepository.updateNewProject("projectDetails", projectDetails)
    }

    fun ProjectClick() {
        type.value = "Project"
    }

    fun CourseClick() {
        type.value = "Course"
    }
}
package com.xlentdevs.xlentlearn.notifications

data class NotificationData(
    val title: String,
    val message: String
)
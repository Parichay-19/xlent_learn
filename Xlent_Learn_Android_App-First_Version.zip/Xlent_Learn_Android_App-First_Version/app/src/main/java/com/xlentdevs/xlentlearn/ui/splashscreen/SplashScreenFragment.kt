package com.xlentdevs.xlentlearn.ui.splashscreen

import android.content.Intent
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.fragment.app.Fragment
import androidx.lifecycle.lifecycleScope
import androidx.navigation.fragment.findNavController
import com.xlentdevs.xlentlearn.commons.textGradientColor
import com.xlentdevs.xlentlearn.databinding.SplashScreenFragmentBinding
import com.xlentdevs.xlentlearn.ui.authentication.MainActivity
import com.xlentdevs.xlentlearn.ui.dashboard.DashBoardActivity
import com.xlentdevs.xlentlearn.utils.PreferenceStore
import kotlinx.coroutines.flow.collect
import kotlinx.coroutines.launch

class SplashScreenFragment : Fragment() {

    private lateinit var viewDataBinding: SplashScreenFragmentBinding
    private lateinit var prefs: PreferenceStore

    private var checkVariable: Boolean = false

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {

        viewDataBinding = SplashScreenFragmentBinding.inflate(inflater, container, false)

        viewDataBinding.fragment = this
        viewDataBinding.lifecycleOwner = this

        prefs = PreferenceStore(requireContext().applicationContext)

        textGradientColor(viewDataBinding.heading, "#00456B", "#73CDFF")

        Handler(Looper.getMainLooper()).postDelayed({
            lifecycleScope.launch {
                prefs.authToken.collect { user ->
                    if (user!!.uid.equals("NA")) {
                        prefs.checkValue.collect { value ->
                            if (value == true) {
                                checkVariable = true
                                prefs.saveFirstTimeUser(false)
                                findNavController().navigate(SplashScreenFragmentDirections.actionSplashScreenFragmentToOnBoardingFragment())
                            } else {
                                if (checkVariable == false) {
                                    val intent = Intent(context, MainActivity::class.java)
                                    intent.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP)
                                    startActivity(intent)
                                    (activity as SplashScreenActivity).finish()
                                }
                            }
                        }
                    } else {
                        val intent = Intent(context, DashBoardActivity::class.java)
                        intent.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP)
                        startActivity(intent)
                        (activity as SplashScreenActivity).finish()
                    }
                }
            }
        }, 3000)

        return viewDataBinding.root
    }
}
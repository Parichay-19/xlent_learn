package com.xlentdevs.xlentlearn.ui.dashboard.course

import android.view.LayoutInflater
import android.view.ViewGroup
import androidx.lifecycle.MutableLiveData
import androidx.recyclerview.widget.DiffUtil
import androidx.recyclerview.widget.ListAdapter
import androidx.recyclerview.widget.RecyclerView
import com.google.firebase.database.DataSnapshot
import com.google.firebase.database.DatabaseError
import com.google.firebase.database.ValueEventListener
import com.google.firebase.database.ktx.database
import com.google.firebase.ktx.Firebase
import com.xlentdevs.xlentlearn.data.db.entity.CourseDetails
import com.xlentdevs.xlentlearn.databinding.ListItemCourseCardBinding

class CourseAdapter internal constructor(
    private val viewModel: CourseViewModel,
    val clickListener: CourseItemListener
) : ListAdapter<CourseDetails, RecyclerView.ViewHolder>(CourseDiffCallback()) {

    class CourseViewHolder(private val binding: ListItemCourseCardBinding) :
        RecyclerView.ViewHolder(binding.root) {
        fun bind(
            viewModel: CourseViewModel,
            clickListener: CourseItemListener,
            item: CourseDetails
        ) {
            binding.viewModel = viewModel
            binding.courseDetails = item
            binding.clickListener = clickListener
            binding.type = "courseLessons"

            Firebase.database.reference.child("courseDetails")
                .child("${item.id}/enrolled/${viewModel.userInfo.value!!.uid}")
                .addListenerForSingleValueEvent(object : ValueEventListener {
                    override fun onDataChange(snapshot: DataSnapshot) {
                        if (snapshot.exists()) {
                            binding.joinBtn.text = "Enrolled"
                        } else {
                            binding.joinBtn.text = "Enroll"
                        }
                    }

                    override fun onCancelled(error: DatabaseError) {

                    }

                })

            binding.executePendingBindings()
        }
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): RecyclerView.ViewHolder {
        val layoutInflater = LayoutInflater.from(parent.context)

        val binding = ListItemCourseCardBinding.inflate(layoutInflater, parent, false)

        return CourseViewHolder(binding)
    }

    override fun onBindViewHolder(holder: RecyclerView.ViewHolder, position: Int) {
        (holder as CourseViewHolder).bind(viewModel, clickListener, getItem(position))
    }

}

class CourseDiffCallback : DiffUtil.ItemCallback<CourseDetails>() {
    override fun areItemsTheSame(oldItem: CourseDetails, newItem: CourseDetails): Boolean {
        return oldItem == newItem
    }

    override fun areContentsTheSame(oldItem: CourseDetails, newItem: CourseDetails): Boolean {
        return oldItem.id == newItem.id
    }
}

class CourseItemListener(val clickListener: (course: CourseDetails, type: String) -> Unit) {
    fun onClick(course: CourseDetails, type: String) = clickListener(course, type)
}

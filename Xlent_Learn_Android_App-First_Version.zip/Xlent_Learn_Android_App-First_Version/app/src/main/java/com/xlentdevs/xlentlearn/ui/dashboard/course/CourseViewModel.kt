package com.xlentdevs.xlentlearn.ui.dashboard.course

import android.app.Application
import androidx.lifecycle.MutableLiveData
import com.xlentdevs.xlentlearn.commons.DefaultViewModel
import com.xlentdevs.xlentlearn.data.Result
import com.xlentdevs.xlentlearn.data.db.entity.CourseDetails
import com.xlentdevs.xlentlearn.data.db.entity.User
import com.xlentdevs.xlentlearn.data.db.remote.FirebaseReferenceValueObserver
import com.xlentdevs.xlentlearn.data.db.repository.RealTimeDataRepository
import com.xlentdevs.xlentlearn.utils.PreferenceStore
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.flow.collect
import kotlinx.coroutines.launch

class CourseViewModel(
    application: Application
) : DefaultViewModel() {

    private val firebaseReferenceObserver = FirebaseReferenceValueObserver()
    private var realTimeDataRepository: RealTimeDataRepository
    var prefs: PreferenceStore

    private var viewModelJob = Job()
    private val uiScope = CoroutineScope(Dispatchers.Main + viewModelJob)

    val userInfo: MutableLiveData<User> = MutableLiveData()

    //For Loading
    val isLoadingCourse = MutableLiveData<Boolean>()

    //Two Way Binding
    val searchBarText = MutableLiveData<String>()

    var coursesList: MutableLiveData<List<CourseDetails>> = MutableLiveData()

    init {
        realTimeDataRepository = RealTimeDataRepository(application)
        prefs = PreferenceStore(application)
        isLoadingCourse.value = true
        getLists("courseDetails", coursesList, isLoadingCourse)
        observeUserDetails()
    }

    fun observeUserDetails() {
        uiScope.launch {
            prefs.authToken.collect { user ->
                userInfo.value = user
            }
        }
    }

    fun getLists(
        path: String,
        list: MutableLiveData<List<CourseDetails>>,
        isLoading: MutableLiveData<Boolean>
    ) {
        realTimeDataRepository.loadAndObserveCourseList(path, firebaseReferenceObserver)
        { result: Result<MutableList<CourseDetails>?> ->
            onResult(null, result)

            if (result is Result.Success) {
                list.value = result.data!!
            }
            isLoading.value = false
        }
    }

    fun getQueryListCourse(
        query: String,
        list: MutableLiveData<List<CourseDetails>>,
        isLoading: MutableLiveData<Boolean>
    ) {
        realTimeDataRepository.queryAndLoadCourseList(
            query,
            firebaseReferenceObserver
        ) { result: Result<MutableList<CourseDetails>?> ->
            onResult(null, result)

            if (result is Result.Success) {
                list.value = result.data!!
            }

            isLoading.value = false
        }
    }

    fun enrollCourse(courseId: String) {
        realTimeDataRepository.enrollCourse("enrolled", userInfo.value!!.uid, courseId)
    }
}
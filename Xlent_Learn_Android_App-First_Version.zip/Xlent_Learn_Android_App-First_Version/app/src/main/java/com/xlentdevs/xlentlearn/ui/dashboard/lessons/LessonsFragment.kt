package com.xlentdevs.xlentlearn.ui.dashboard.lessons

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.activity.OnBackPressedCallback
import androidx.fragment.app.Fragment
import androidx.fragment.app.viewModels
import androidx.navigation.fragment.findNavController
import androidx.navigation.fragment.navArgs
import androidx.recyclerview.widget.RecyclerView
import com.google.android.material.bottomnavigation.BottomNavigationView
import com.xlentdevs.xlentlearn.R
import com.xlentdevs.xlentlearn.databinding.LessonsFragmentBinding
import com.xlentdevs.xlentlearn.ui.dashboard.DashBoardActivity
import com.xlentdevs.xlentlearn.utils.showSnackBar

class LessonsFragment: Fragment() {

    private val args : LessonsFragmentArgs by navArgs()

    private val viewModel: LessonsViewModel by viewModels{
        LessonsViewModelFactory(
            requireNotNull(this.activity).application,
            args.id!!,
            args.type,
            args.name,
            args.photo
        )
    }

    private lateinit var listAdapter: LessonsCourseAdapter
    private lateinit var listAdapterObserver: RecyclerView.AdapterDataObserver
    private lateinit var binding: LessonsFragmentBinding

    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        binding = LessonsFragmentBinding.inflate(inflater, container, false)
        binding.lifecycleOwner = this
        binding.fragment = this
        binding.viewModel = viewModel

        setUpObservers()
        setupListAdapter()

        return binding.root
    }

    private fun setUpObservers() {
        viewModel.snackBarText.observe(viewLifecycleOwner, { text ->
            view?.showSnackBar(text, R.id.containerDashBoardActivity)
        })

        viewModel.dataLoading.observe(viewLifecycleOwner, { value ->
            (activity as DashBoardActivity).showGlobalProgressBar(value)
        })

        viewModel.isLoading.observe(viewLifecycleOwner, {value ->
            if(value == true) binding.progressLesson.visibility = View.VISIBLE
            else binding.progressLesson.visibility = View.GONE
        })
    }

    private fun setupListAdapter() {
        listAdapterObserver = (object : RecyclerView.AdapterDataObserver() {
            override fun onItemRangeInserted(positionStart: Int, itemCount: Int) {
                binding.recyclerViewLessons.scrollToPosition(positionStart)
            }
        })

        listAdapter = LessonsCourseAdapter(viewModel, LessonsItemListener {course ->
            findNavController().navigate(LessonsFragmentDirections.actionLessonsFragmentToVideosFragment(course.id))
        })

        listAdapter.registerAdapterDataObserver(listAdapterObserver)
        binding.recyclerViewLessons.adapter = listAdapter
    }
}
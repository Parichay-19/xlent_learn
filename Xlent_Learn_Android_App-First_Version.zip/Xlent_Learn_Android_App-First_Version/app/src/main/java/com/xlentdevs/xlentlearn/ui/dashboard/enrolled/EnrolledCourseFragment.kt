package com.xlentdevs.xlentlearn.ui.dashboard.enrolled

import android.os.Bundle
import android.util.Log
import androidx.fragment.app.Fragment
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.fragment.app.viewModels
import androidx.navigation.fragment.findNavController
import androidx.recyclerview.widget.RecyclerView
import com.xlentdevs.xlentlearn.R
import com.xlentdevs.xlentlearn.databinding.FragmentEnrolledCoursesBinding
import com.xlentdevs.xlentlearn.databinding.FragmentNotificationBinding
import com.xlentdevs.xlentlearn.ui.dashboard.DashBoardActivity
import com.xlentdevs.xlentlearn.ui.dashboard.home.HomeFragmentDirections
import com.xlentdevs.xlentlearn.ui.dashboard.notification.NotificationAdapter
import com.xlentdevs.xlentlearn.ui.dashboard.notification.NotificationItemListener
import com.xlentdevs.xlentlearn.ui.dashboard.notification.NotificationViewModel
import com.xlentdevs.xlentlearn.ui.dashboard.notification.NotificationViewModelFactory
import com.xlentdevs.xlentlearn.utils.showSnackBar

class EnrolledCourseFragment : Fragment() {

    private val viewModel: EnrolledCourseViewModel by viewModels {
        EnrolledCourseViewModelFactory(
            requireNotNull(this.activity).application,
        )
    }

    private lateinit var listAdapterEnrolledCourse: EnrolledCourseAdapter
    private lateinit var listAdapterObserverEnrolledCourse: RecyclerView.AdapterDataObserver

    private lateinit var binding: FragmentEnrolledCoursesBinding

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        // Inflate the layout for this fragment
        binding = FragmentEnrolledCoursesBinding.inflate(inflater, container, false)
        binding.lifecycleOwner = this
        binding.fragment = this
        binding.viewModel = viewModel

        setUpObservers()
        setupListAdapterProject()

        return binding.root
    }

    private fun setupListAdapterProject() {
        listAdapterObserverEnrolledCourse = (object : RecyclerView.AdapterDataObserver() {
            override fun onItemRangeInserted(positionStart: Int, itemCount: Int) {
                binding.recyclerView.scrollToPosition(positionStart)
            }
        })

        listAdapterEnrolledCourse =
            EnrolledCourseAdapter(viewModel, EnrolledCourseItemListener { course, type ->
                findNavController().navigate(
                    EnrolledCourseFragmentDirections.actionEnrolledCourseFragmentToLessonsFragment(
                        course.id,
                        type,
                        course.name,
                        course.thumbnail
                    )
                )
            })

        listAdapterEnrolledCourse.registerAdapterDataObserver(listAdapterObserverEnrolledCourse)
        binding.recyclerView.adapter = listAdapterEnrolledCourse
    }

    private fun setUpObservers() {
        viewModel.snackBarText.observe(viewLifecycleOwner, { text ->
            view?.showSnackBar(text, R.id.containerDashBoardActivity)
        })

        viewModel.dataLoading.observe(viewLifecycleOwner, { value ->
            (activity as DashBoardActivity).showGlobalProgressBar(value)
        })

        viewModel.isLoadingEnrolledCourses.observe(viewLifecycleOwner, { value ->
            if (value == true) binding.progressProject.visibility = View.VISIBLE
            else binding.progressProject.visibility = View.GONE
        })
    }
}
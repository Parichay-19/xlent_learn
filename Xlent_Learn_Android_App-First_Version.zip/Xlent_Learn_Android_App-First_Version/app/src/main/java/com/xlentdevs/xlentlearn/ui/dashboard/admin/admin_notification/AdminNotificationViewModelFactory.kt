package com.xlentdevs.xlentlearn.ui.dashboard.admin.admin_notification

import android.app.Application
import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import com.xlentdevs.xlentlearn.ui.dashboard.admin.admin_post.AdminPostViewModel

class AdminNotificationViewModelFactory(
    private val application: Application,
): ViewModelProvider.Factory {

    override fun <T : ViewModel> create(modelClass: Class<T>): T {
        if (modelClass.isAssignableFrom(AdminNotificationViewModel::class.java)){
            return AdminNotificationViewModel(application) as T
        }
        throw IllegalArgumentException("Unknown ViewModel !")
    }
}
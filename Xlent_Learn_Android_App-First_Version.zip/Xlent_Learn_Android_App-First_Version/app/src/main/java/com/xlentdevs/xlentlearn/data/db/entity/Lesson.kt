package com.xlentdevs.xlentlearn.data.db.entity

data class Lesson (
    var id: String = ""
)
package com.xlentdevs.xlentlearn.ui.dashboard.videos

import android.app.Application
import android.util.Log
import androidx.lifecycle.MutableLiveData
import com.xlentdevs.xlentlearn.commons.DefaultViewModel
import com.xlentdevs.xlentlearn.data.db.repository.RealTimeDataRepository
import com.xlentdevs.xlentlearn.data.model.PlaylistItemsModel
import com.xlentdevs.xlentlearn.network.ApiConfig
import com.xlentdevs.xlentlearn.utils.PreferenceStore
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import retrofit2.Call
import retrofit2.Callback
import retrofit2.Response

class VideosViewModel(
    application: Application,
    var playlistId: String
) : DefaultViewModel() {
    private val BASE_URL = "https://www.googleapis.com/youtube/v3/"

    private var realTimeDataRepository: RealTimeDataRepository
    var prefs: PreferenceStore

    //For Loading
    val isLoading = MutableLiveData<Boolean>()

    var isAllItemLoaded = MutableLiveData<Boolean>()
    var playlistItem = MutableLiveData<PlaylistItemsModel?>()

    var nextPageToken: String? = null

    private var viewModelJob = Job()
    private val uiScope = CoroutineScope(Dispatchers.Main + viewModelJob)

    init {
        realTimeDataRepository = RealTimeDataRepository(application)
        prefs = PreferenceStore(application)
        getPlaylistItems(playlistId)
    }

    fun getPlaylistItems(id: String) {
        isLoading.value = true
        val client = ApiConfig
            .getService(BASE_URL)
            .getPlaylistItems(
                "snippet,contentDetails",
                id,
                nextPageToken
            )

        client.enqueue(object : Callback<PlaylistItemsModel> {
            override fun onResponse(
                call: Call<PlaylistItemsModel>,
                response: Response<PlaylistItemsModel>
            ) {
                isLoading.value = false
                val data = response.body()
                if (data != null){
                    if (data.nextPageToken != null){
                        nextPageToken = data.nextPageToken
                    } else {
                        nextPageToken = null
                        isAllItemLoaded.value = true
                    }
                    if (data.items.isNotEmpty()){
                        playlistItem.value = data
                    }
                }
            }

            override fun onFailure(call: Call<PlaylistItemsModel>, t: Throwable) {
                isLoading.value = false
                Log.e("Ajeet", "Failure: ", t)
            }
        })
    }
}
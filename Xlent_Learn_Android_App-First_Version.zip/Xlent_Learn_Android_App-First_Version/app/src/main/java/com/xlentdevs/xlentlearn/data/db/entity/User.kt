package com.xlentdevs.xlentlearn.data.db.entity

data class User(
    var uid: String = "",
    var name: String = "",
    var email: String = "",
    var profile: String = "",
    var admin: Boolean = false
)
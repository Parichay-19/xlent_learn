package com.xlentdevs.xlentlearn.ui.dashboard.project

import android.app.Application
import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import com.xlentdevs.xlentlearn.ui.dashboard.course.CourseViewModel

class ProjectViewModelFactory(
    private val application: Application
): ViewModelProvider.Factory {

    override fun <T : ViewModel> create(modelClass: Class<T>): T {
        if (modelClass.isAssignableFrom(ProjectViewModel::class.java)){
            return ProjectViewModel(application) as T
        }
        throw IllegalArgumentException("Unknown ViewModel !")
    }
}
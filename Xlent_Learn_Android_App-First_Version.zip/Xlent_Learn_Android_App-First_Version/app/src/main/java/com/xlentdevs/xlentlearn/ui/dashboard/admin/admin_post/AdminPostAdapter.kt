package com.xlentdevs.xlentlearn.ui.dashboard.admin.admin_post

import android.util.Log
import android.view.LayoutInflater
import android.view.ViewGroup
import androidx.recyclerview.widget.DiffUtil
import androidx.recyclerview.widget.ListAdapter
import androidx.recyclerview.widget.RecyclerView
import com.xlentdevs.xlentlearn.data.db.entity.Lesson
import com.xlentdevs.xlentlearn.databinding.ListItemPlaylistIdBinding

class AdminPostAdapter internal constructor(
    private val viewModel: AdminPostViewModel
) : ListAdapter<Lesson, RecyclerView.ViewHolder>(AdminPostDiffCallback()) {

    class AdminPostViewHolder(private val binding: ListItemPlaylistIdBinding) :
        RecyclerView.ViewHolder(binding.root) {
        fun bind(
            viewModel: AdminPostViewModel,
            item: Lesson,
            position: Int
        ) {
            binding.viewModel = viewModel
            binding.playlistId.text = item.id

            binding.lessonNumber.text = "" + (position+1)

            binding.executePendingBindings()
        }
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): RecyclerView.ViewHolder {
        val layoutInflater = LayoutInflater.from(parent.context)

        val binding = ListItemPlaylistIdBinding.inflate(layoutInflater, parent, false)

        return AdminPostViewHolder(binding)
    }

    override fun onBindViewHolder(holder: RecyclerView.ViewHolder, position: Int) {
        (holder as AdminPostViewHolder).bind(viewModel, getItem(position), position)
    }

}

class AdminPostDiffCallback : DiffUtil.ItemCallback<Lesson>() {
    override fun areItemsTheSame(oldItem: Lesson, newItem: Lesson): Boolean {
        return oldItem == newItem
    }

    override fun areContentsTheSame(oldItem: Lesson, newItem: Lesson): Boolean {
        return oldItem.id == newItem.id
    }
}
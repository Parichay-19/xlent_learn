package com.xlentdevs.xlentlearn.ui.dashboard.request

import android.app.Application
import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import com.xlentdevs.xlentlearn.ui.dashboard.notification.NotificationViewModel

class RequestCourseViewModelFactory(
    private val application: Application
) : ViewModelProvider.Factory {

    override fun <T : ViewModel> create(modelClass: Class<T>): T {
        if (modelClass.isAssignableFrom(RequestCourseViewModel::class.java)) {
            return RequestCourseViewModel(application) as T
        }
        throw IllegalArgumentException("Unknown ViewModel !")
    }
}
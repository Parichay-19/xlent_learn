package com.xlentdevs.xlentlearn.data.db.entity

data class RequestDetails(
    var id: String = "",
    var name: String = "",
    var desc: String = ""
)
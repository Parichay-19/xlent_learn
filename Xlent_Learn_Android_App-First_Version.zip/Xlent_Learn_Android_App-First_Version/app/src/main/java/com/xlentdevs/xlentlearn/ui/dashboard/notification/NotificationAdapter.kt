package com.xlentdevs.xlentlearn.ui.dashboard.notification

import android.view.LayoutInflater
import android.view.ViewGroup
import androidx.recyclerview.widget.DiffUtil
import androidx.recyclerview.widget.ListAdapter
import androidx.recyclerview.widget.RecyclerView
import com.xlentdevs.xlentlearn.data.db.entity.NotificationDetails
import com.xlentdevs.xlentlearn.databinding.ListItemNotificationBinding

class NotificationAdapter internal constructor(
    private val viewModel: NotificationViewModel,
    val clickListener: NotificationItemListener
) : ListAdapter<NotificationDetails, RecyclerView.ViewHolder>(NotificationDiffCallback()) {

    class NotificationViewHolder(private val binding: ListItemNotificationBinding) :
        RecyclerView.ViewHolder(binding.root) {
        fun bind(
            viewModel: NotificationViewModel,
            clickListener: NotificationItemListener,
            item: NotificationDetails
        ) {
            binding.viewModel = viewModel
            binding.notificationDetails = item
            binding.clickListener = clickListener

            binding.executePendingBindings()
        }
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): RecyclerView.ViewHolder {
        val layoutInflater = LayoutInflater.from(parent.context)

        val binding = ListItemNotificationBinding.inflate(layoutInflater, parent, false)

        return NotificationViewHolder(binding)
    }

    override fun onBindViewHolder(holder: RecyclerView.ViewHolder, position: Int) {
        (holder as NotificationViewHolder).bind(viewModel, clickListener, getItem(position))
    }

}

class NotificationDiffCallback : DiffUtil.ItemCallback<NotificationDetails>() {

    override fun areItemsTheSame(
        oldItem: NotificationDetails,
        newItem: NotificationDetails
    ): Boolean {
        return oldItem == newItem
    }

    override fun areContentsTheSame(
        oldItem: NotificationDetails,
        newItem: NotificationDetails
    ): Boolean {
        return oldItem.title == newItem.title
    }
}

class NotificationItemListener(val clickListener: (notification: NotificationDetails) -> Unit) {
    fun onClick(notification: NotificationDetails) = clickListener(notification)
}
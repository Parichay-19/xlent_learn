package com.xlentdevs.xlentlearn.data.db.repository

import android.app.Application
import androidx.lifecycle.MutableLiveData
import com.xlentdevs.xlentlearn.data.Result
import com.xlentdevs.xlentlearn.data.db.entity.*
import com.xlentdevs.xlentlearn.data.db.remote.FirebaseDataSource
import com.xlentdevs.xlentlearn.data.db.remote.FirebaseReferenceValueObserver

class RealTimeDataRepository(private var application: Application?) {

    private val firebaseDatabaseService = FirebaseDataSource()

    //------------------------------Update Starts---------------------------------
    fun updateNewUser(path: String, user: User) {
        firebaseDatabaseService.updateNewUser(path, user)
    }

    fun updateNewCourse(path: String, courseDetails: CourseDetails): String {
        val courseId = firebaseDatabaseService.updateNewCourse(path, courseDetails)
        return courseId
    }

    fun updateNewProject(path: String, projectDetails: ProjectDetails): String {
        val projectId = firebaseDatabaseService.updateNewProject(path, projectDetails)
        return projectId
    }

    fun updateCourseLessons(path: String, courseLesson: String, id: String): Boolean {
        firebaseDatabaseService.updateCourseLessons(path, courseLesson, id)
        return true
    }

    fun updateNotificationDetails(path: String, notificationDetails: NotificationDetails): String {
        val notificationId =
            firebaseDatabaseService.updateNotificationDetails(path, notificationDetails)
        return notificationId
    }

    fun updateNewCourseRequest(path: String, requestDetails: RequestDetails) : String {
        val requestId = firebaseDatabaseService.updateNewCourseRequest(path, requestDetails)
        return requestId
    }

    fun enrollCourse(path: String, uid: String, courseId: String): Boolean {
        firebaseDatabaseService.enrollCourse(path, uid, courseId)
        return true
    }
    //------------------------------Update Ends-----------------------------------

    //------------------------------Load & Observe Starts---------------------------------
    fun loadAndObserveUserInfo(
        path: String,
        userID: String,
        observer: FirebaseReferenceValueObserver,
        b: (Result<User>) -> Unit
    ) {
        firebaseDatabaseService.attachUserInfoObserver(path, User::class.java, userID, observer, b)
    }

    fun loadAndObserveList(
        path: String, id: String, observer: FirebaseReferenceValueObserver, b: ((
            Result<MutableList<Lesson>?>
        ) -> Unit)
    ) {
        firebaseDatabaseService.attachCourseLessonObserver(
            path,
            id,
            Lesson::class.java,
            observer,
            b
        )
    }

    fun loadAndObserveCourseList(
        path: String, observer: FirebaseReferenceValueObserver, b: ((
            Result<MutableList<CourseDetails>?>
        ) -> Unit)
    ) {
        firebaseDatabaseService.attachCourseListObserver(
            path,
            CourseDetails::class.java,
            observer,
            b
        )
    }

    fun loadAndObserveProjectList(
        path: String, observer: FirebaseReferenceValueObserver, b: ((
            Result<MutableList<ProjectDetails>?>
        ) -> Unit)
    ) {
        firebaseDatabaseService.attachProjectListObserver(
            path,
            ProjectDetails::class.java,
            observer,
            b
        )
    }

    fun loadAndObserveNotificationList(
        path: String, observer: FirebaseReferenceValueObserver, b: ((
            Result<MutableList<NotificationDetails>?>
        ) -> Unit)
    ) {
        firebaseDatabaseService.attachNotificationListObserver(
            path,
            NotificationDetails::class.java,
            observer,
            b
        )
    }

    fun loadAndObserveEnrolledCourseIdList(
        path: String, userID: String, observer: FirebaseReferenceValueObserver, b: ((
            Result<MutableList<String>>
        ) -> Unit)
    ){
        firebaseDatabaseService.attachEnrolledCoursesIdListObserver(
            path,
            userID,
            String::class.java,
            observer,
            b
        )
    }

    fun loadAndObserveEnrolledCourse(
        path: String,
        courseId: String,
        observer: FirebaseReferenceValueObserver,
        b: (Result<CourseDetails>) -> Unit
    ) {
        firebaseDatabaseService.attachEnrolledCourseObserver(path, CourseDetails::class.java, courseId, observer, b)
    }
    //------------------------------Load & Observe Ends---------------------------------

    //------------------------------Query Data Starts------------------------------------------
    fun queryAndLoadCourseList(
        query: String, observer: FirebaseReferenceValueObserver, b: ((
            Result<MutableList<CourseDetails>?>
        ) -> Unit)
    ) {
        firebaseDatabaseService.attachCourseQueryListObserver(
            query,
            CourseDetails::class.java,
            observer,
            b
        )
    }

    fun queryAndLoadProjectList(
        query: String, observer: FirebaseReferenceValueObserver, b: ((
            Result<MutableList<ProjectDetails>?>
        ) -> Unit)
    ) {
        firebaseDatabaseService.attachProjectQueryListObserver(
            query,
            ProjectDetails::class.java,
            observer,
            b
        )
    }

    //----------------------------Query Data Ends----------------------------------------
}
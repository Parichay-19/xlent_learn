package com.xlentdevs.xlentlearn.data.db.remote

import android.net.Uri
import com.google.android.gms.tasks.Task
import com.google.firebase.storage.FirebaseStorage

class FirebaseStorageSource {
    private val storageInstance = FirebaseStorage.getInstance()

    fun uploadCourseImage(courseName: String, bArr: ByteArray): Task<Uri> {
        val path = "courseImage/$courseName/course_image"
        val ref = storageInstance.reference.child(path)

        return ref.putBytes(bArr).continueWithTask {
            ref.downloadUrl
        }
    }

    fun uploadProjectImage(projectName: String, bArr: ByteArray): Task<Uri> {
        val path = "projectImage/$projectName/project_image"
        val ref = storageInstance.reference.child(path)

        return ref.putBytes(bArr).continueWithTask {
            ref.downloadUrl
        }
    }
}
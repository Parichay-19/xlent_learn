package com.xlentdevs.xlentlearn.data.db.entity

data class NotificationDetails(
    var id: String = "",
    var title: String = "",
    var desc: String = ""
)
package com.xlentdevs.xlentlearn.ui.splashscreen.onboarding

import android.os.Bundle
import androidx.fragment.app.Fragment
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.lifecycle.lifecycleScope
import com.xlentdevs.xlentlearn.R
import com.xlentdevs.xlentlearn.databinding.FragmentOnBoardingBinding
import com.xlentdevs.xlentlearn.ui.splashscreen.OnBoardViewPagerAdapter
import com.xlentdevs.xlentlearn.ui.splashscreen.onboarding.frags.OnBoardOneFragment
import com.xlentdevs.xlentlearn.ui.splashscreen.onboarding.frags.OnBoardThreeFragment
import com.xlentdevs.xlentlearn.ui.splashscreen.onboarding.frags.OnBoardTwoFragment
import com.xlentdevs.xlentlearn.utils.PreferenceStore
import kotlinx.coroutines.launch

class OnBoardingFragment : Fragment() {

    private lateinit var binding: FragmentOnBoardingBinding

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        binding = FragmentOnBoardingBinding.inflate(inflater, container, false)
        binding.lifecycleOwner = this
        binding.fragment = this

        val fragmentList = arrayListOf<Fragment>(
            OnBoardOneFragment(),
            OnBoardTwoFragment(),
            OnBoardThreeFragment()
        )

        val adapter = OnBoardViewPagerAdapter(
            fragmentList,
            requireActivity().supportFragmentManager,
            lifecycle
        )

        binding.viewPager.adapter = adapter

        return binding.root
    }
}
package com.xlentdevs.xlentlearn.notifications

class Constants {

    companion object {
        const val BASE_URL = "https://fcm.googleapis.com"
        const val SERVER_KEY =
            "AAAAhe6ovS4:APA91bHhzvihch0NMV0zt8gnYDt2F5Vn5K0IUmysSt7OYXadBaUsedGMIG6mwqd_FtcHFA8dPwjJ9qCLviomQ-_1ZHge5RaN-jl354ZiF1Uu7tQb1V6F-JJoeZIn4Px-GQP9jNChufsl"
        const val CONTENT_TYPE = "application/json"
    }
}
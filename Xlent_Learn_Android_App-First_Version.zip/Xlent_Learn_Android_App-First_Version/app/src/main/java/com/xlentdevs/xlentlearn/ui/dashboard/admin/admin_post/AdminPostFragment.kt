package com.xlentdevs.xlentlearn.ui.dashboard.admin.admin_post

import android.os.Bundle
import android.util.Log
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.fragment.app.Fragment
import androidx.fragment.app.viewModels
import androidx.navigation.fragment.findNavController
import androidx.navigation.fragment.navArgs
import androidx.recyclerview.widget.RecyclerView
import com.xlentdevs.xlentlearn.R
import com.xlentdevs.xlentlearn.databinding.AdminPostFragmentBinding
import com.xlentdevs.xlentlearn.utils.showSnackBar

class AdminPostFragment: Fragment(){

    private val args : AdminPostFragmentArgs by navArgs()

    private val viewModel: AdminPostViewModel by viewModels{
        AdminPostViewModelFactory(
            requireNotNull(this.activity).application,
            args.playlistId!!
        )
    }

    private lateinit var listAdapter: AdminPostAdapter
    private lateinit var listAdapterObserver: RecyclerView.AdapterDataObserver
    private lateinit var binding: AdminPostFragmentBinding

    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        binding = AdminPostFragmentBinding.inflate(inflater, container, false)
        binding.lifecycleOwner = this
        binding.fragment = this
        binding.viewModel = viewModel

        setObservers()
        setupListAdapter()

        return binding.root
    }

    private fun setObservers() {
        viewModel.snackBarText.observe(viewLifecycleOwner, { text ->
            view?.showSnackBar(text, R.id.containerDashBoardActivity)
        })

        viewModel.isDone.observe(viewLifecycleOwner, { value ->
            if (value == true) {
                moveToProfilePageFragment()
            }
        })
    }

    private fun setupListAdapter() {
        listAdapterObserver = (object : RecyclerView.AdapterDataObserver() {
            override fun onItemRangeInserted(positionStart: Int, itemCount: Int) {
                binding.recyclerView.scrollToPosition(positionStart)
            }
        })

        listAdapter = AdminPostAdapter(viewModel)

        listAdapter.registerAdapterDataObserver(listAdapterObserver)
        binding.recyclerView.adapter = listAdapter
    }

    private fun moveToProfilePageFragment() {
        findNavController().popBackStack(R.id.profileFragment, false)
    }
}
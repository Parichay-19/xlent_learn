package com.xlentdevs.xlentlearn.ui.authentication.signup

import android.app.Activity
import android.content.Intent
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.activity.result.contract.ActivityResultContracts
import androidx.fragment.app.Fragment
import androidx.fragment.app.viewModels
import com.google.android.gms.auth.api.credentials.IdToken
import com.google.android.gms.auth.api.signin.GoogleSignIn
import com.google.android.gms.auth.api.signin.GoogleSignInClient
import com.google.android.gms.auth.api.signin.GoogleSignInOptions
import com.google.android.gms.common.api.ApiException
import com.google.android.gms.tasks.OnCompleteListener
import com.google.firebase.auth.GoogleAuthProvider
import com.google.firebase.database.DataSnapshot
import com.google.firebase.database.DatabaseError
import com.google.firebase.database.ValueEventListener
import com.google.firebase.database.ktx.database
import com.google.firebase.ktx.Firebase
import com.xlentdevs.xlentlearn.R
import com.xlentdevs.xlentlearn.databinding.SignupFragmentBinding
import com.xlentdevs.xlentlearn.ui.authentication.MainActivity
import com.xlentdevs.xlentlearn.ui.dashboard.DashBoardActivity
import com.xlentdevs.xlentlearn.utils.showSnackBar

class SignUpFragment : Fragment() {

    private val viewModel: SignUpViewModel by viewModels {
        SignUpViewModelFactory(
            requireNotNull(this.activity).application
        )
    }

    private lateinit var binding: SignupFragmentBinding
    private lateinit var googleSignInClient: GoogleSignInClient

    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        binding = SignupFragmentBinding.inflate(inflater, container, false)
        binding.lifecycleOwner = this
        binding.fragment = this
        binding.viewModel = viewModel

        initGoogleSignInClient()
        setUpObservers()

        return binding.root
    }

    private fun setUpObservers() {
        viewModel.snackBarText.observe(viewLifecycleOwner, { text ->
            view?.showSnackBar(text, R.id.containerMainActivity)
        })

        viewModel.dataLoading.observe(viewLifecycleOwner, { value ->
            (activity as MainActivity).showGlobalProgressBar(value)
        })

        viewModel.isRegistered.observe(viewLifecycleOwner, { user ->
            if (user != null) {
                moveToDashboardScreen()
            }
        })
    }

    fun moveToLoginPage() {

    }

    private fun moveToDashboardScreen() {
        val intent = Intent(context, DashBoardActivity::class.java)
        startActivity(intent)
        (activity as MainActivity).finish()
    }

    //-------------------------Google Sign Up code starts---------------------------

    private fun initGoogleSignInClient() {
        val gso = GoogleSignInOptions.Builder(GoogleSignInOptions.DEFAULT_SIGN_IN)
            .requestIdToken(resources.getString(R.string.default_web_client_id))
            .requestEmail()
            .build()

        googleSignInClient = GoogleSignIn.getClient(requireContext(), gso)
    }

    fun signInUsingGoogle() {
        val signInGoogleIntent = googleSignInClient.signInIntent
        resultLauncher.launch(signInGoogleIntent)
    }

    private var resultLauncher =
        registerForActivityResult(ActivityResultContracts.StartActivityForResult()) { result ->
            if (result.resultCode == Activity.RESULT_OK) {

                // There are no request codes
                val data: Intent? = result.data

                val task = GoogleSignIn.getSignedInAccountFromIntent(data)
                try {
                    val account = task.getResult(ApiException::class.java)!!

                    Firebase.database.reference.child("users").orderByChild("email")
                        .startAt(account.email).endAt(account.email + "\uF8FF")
                        .addValueEventListener(object : ValueEventListener {
                            override fun onDataChange(snapshot: DataSnapshot) {
                                if (snapshot.exists()){
                                    viewModel.snackBarText.value = "User Already Exist"
                                    googleSignInClient.signOut()
                                } else{
                                    viewModel.dataLoading.value = true
                                    getGoogleAuthCredential(account.idToken!!)
                                }
                            }

                            override fun onCancelled(error: DatabaseError) {
                                viewModel.snackBarText.value = "Try Again !"
                            }

                        })
                } catch (e: ApiException) {
                    viewModel.snackBarText.value = "Unknown Error, Try Again !"
                }
            }
        }

    private fun getGoogleAuthCredential(idToken: String) {
        val googleAuthCredential = GoogleAuthProvider.getCredential(idToken, null)
        googleSignInClient.signOut().addOnCompleteListener(OnCompleteListener {
            viewModel.googleSignUp(googleAuthCredential)
        })
    }

    //------------------------------Google Sign Up code ends-----------------------------
}